﻿// js/game.js - Main game controller
const GameController = {
  difficulty: null,
  activeMode: null,
  nextPetOverride: null,
  infiniteCurrentStreak: 0,
  infiniteLastPersist: 0,
  infiniteCooldownMs: 0,
  lastStreakNotified: 0,
  pet: null,
  currentMinigame: null,
  gameLoop: null,
  gameStartTime: null,
  gameOverTime: null,
  deathSound: null,
  poopPenalty: 0,
  isGameOver: false,
  isPaused: false,
  statDecayPaused: false,
  statPauseDepth: 0,
  lastTickTime: null,
  sessionTimerInterval: null,
  streakToastTimer: null,
  tutorialState: null,
  tutorialAutoStarted: false,
  pendingExtremeUnlock: false,
  ui: {},

  init(difficulty, options = {}) {
    this.stopGameLoop();
    this.stopSessionTimer();
    this.teardownTutorial({ resume: false });
    this.resumeStatDecay(true);

    const normalisedDifficulty = typeof difficulty === 'string'
      ? difficulty.toLowerCase().trim()
      : 'pikmin';
    this.difficulty = Object.prototype.hasOwnProperty.call(GameConfig.difficulties, normalisedDifficulty)
      ? normalisedDifficulty
      : 'pikmin';

    const requestedMode = options && options.mode != null
      ? String(options.mode).toLowerCase().trim()
      : null;
    this.activeMode = requestedMode || this.difficulty;

    const override = options && options.petTypeOverride != null
      ? String(options.petTypeOverride).toLowerCase().trim()
      : null;
    this.nextPetOverride = override && override.length ? override : null;

    this.isGameOver = false;
    this.isPaused = false;
    this.currentMinigame = null;
    this.gameLoop = null;
    this.gameOverTime = null;
    this.poopPenalty = 0;
    this.statPauseDepth = 0;
    this.statDecayPaused = false;
    this.streakToastTimer = null;
    this.infiniteLastPersist = 0;
    this.infiniteCooldownMs = 0;
    this.tutorialAutoStarted = false;
    this.lastStreakNotified = 0;

    if (this.deathSound) {
      try {
        this.deathSound.pause();
      } catch (_) {}
      this.deathSound = null;
    }

    this.gameStartTime = Date.now();
    this.lastTickTime = this.gameStartTime;

    this.setupPet();
    this.renderGameScreen();
    this.startSessionTimer();
    this.startGameLoop();
    this.startBackgroundMusic();
    this.persistInfiniteStats(true);
    this.evaluateInfiniteStreak({ suppressToast: true });
    this.updateAfterTick();

    console.log(`Game initialized with ${this.activeMode} mode (${this.difficulty} difficulty)`);
  },

  startBackgroundMusic() {
    if (typeof AudioManager === 'undefined') {
      return;
    }

    AudioManager.stopAllMusic();

    let lobbyMusic = document.getElementById('lobbyMusic');
    if (!lobbyMusic) {
      lobbyMusic = document.createElement('audio');
      lobbyMusic.id = 'lobbyMusic';
      lobbyMusic.src = this.difficulty === 'kuchi' ? 'assets/audio/lobby_death_music.mp3' : 'assets/audio/lobby_music.mp3';
      lobbyMusic.loop = true;
      document.body.appendChild(lobbyMusic);
    } else {
      lobbyMusic.src = this.difficulty === 'kuchi' ? 'assets/audio/lobby_death_music.mp3' : 'assets/audio/lobby_music.mp3';
    }

    const targetVolume = typeof AudioManager.musicVolume === 'number' ? AudioManager.musicVolume : 1;
    lobbyMusic.volume = 0;
    lobbyMusic.play().catch((error) => console.log('Could not play lobby music:', error));

    let fadeVolume = 0;
    const fadeInterval = setInterval(() => {
      fadeVolume += 0.05;
      if (fadeVolume >= targetVolume) {
        lobbyMusic.volume = targetVolume;
        clearInterval(fadeInterval);
      } else {
        lobbyMusic.volume = fadeVolume;
      }
    }, 50);
  },

  setupPet() {
    const petNames = {
      pikmin: 'Pikmin',
      kuchi: 'Kuchi',
      chikawa: 'Chikawa'
    };

    const normalisePetType = (value) => {
      const key = typeof value === 'string' ? value.toLowerCase().trim() : '';
      return petNames[key] ? key : 'pikmin';
    };

    const clampPersistedStat = (value) => {
      const numberValue = Number(value);
      const fallback = GameConfig.stats.startingValue || 50;
      if (!Number.isFinite(numberValue)) {
        return fallback;
      }
      const safeMinimum = Math.max(30, fallback);
      if (numberValue <= 0) {
        return safeMinimum;
      }
      return Math.max(0, Math.min(GameConfig.stats.maxValue, Math.round(numberValue)));
    };

    let petType = 'pikmin';
    if (this.activeMode !== 'infinite') {
      if (this.difficulty === 'kuchi') {
        petType = 'kuchi';
      } else if (this.difficulty === 'tutorial') {
        petType = 'chikawa';
      }
    }

    if (this.nextPetOverride) {
      petType = normalisePetType(this.nextPetOverride);
      this.nextPetOverride = null;
    } else if (this.activeMode === 'infinite' && typeof StateStore !== 'undefined' && typeof StateStore.getInfiniteAppearance === 'function') {
      try {
        if (!StateStore.isReady || StateStore.isReady()) {
          const storedAppearance = StateStore.getInfiniteAppearance();
          if (storedAppearance) {
            petType = normalisePetType(storedAppearance);
          }
        }
      } catch (error) {
        console.warn('GameController: unable to apply stored infinite appearance', error);
      }
    }

    this.pet = {
      name: petNames[petType] || 'Pikmin',
      type: petType,
      hunger: GameConfig.stats.startingValue,
      sleep: GameConfig.stats.startingValue,
      happiness: GameConfig.stats.startingValue,
      lastUpdate: Date.now()
    };

    if (this.activeMode === 'infinite' && typeof StateStore !== 'undefined' && typeof StateStore.getInfiniteStats === 'function') {
      try {
        if (!StateStore.isReady || StateStore.isReady()) {
          const storedStats = StateStore.getInfiniteStats();
          if (storedStats && typeof storedStats === 'object') {
            this.pet.hunger = clampPersistedStat(storedStats.hunger);
            this.pet.sleep = clampPersistedStat(storedStats.sleep);
            this.pet.happiness = clampPersistedStat(storedStats.happiness);
          }
          if (typeof StateStore.getInfiniteStreak === 'function') {
            this.infiniteCurrentStreak = Math.max(0, Number(StateStore.getInfiniteStreak()) || 0);
            this.lastStreakNotified = this.infiniteCurrentStreak;
          }
        }
      } catch (error) {
        console.warn('GameController: unable to apply stored infinite stats', error);
      }
    } else {
      this.infiniteCurrentStreak = 0;
      this.lastStreakNotified = 0;
    }

    try {
      if (typeof PetSystem !== 'undefined' && typeof PetSystem.cleanup === 'function') {
        PetSystem.cleanup();
      }
    } catch (error) {
      console.warn('PetSystem cleanup failed', error);
    }

    setTimeout(() => {
      try {
        if (typeof PetSystem !== 'undefined' && typeof PetSystem.init === 'function') {
          PetSystem.init(this.pet.type);
        }
      } catch (error) {
        console.error('PetSystem failed to initialise', error);
      }
    }, 100);
  },

  renderGameScreen() {
    const container = document.getElementById('gameContainer');
    if (!container) {
      return;
    }

    const gameScreen = document.querySelector('.game-screen');
    if (gameScreen) {
      gameScreen.classList.toggle('infinite-mode', this.activeMode === 'infinite');
      gameScreen.classList.remove('tutorial-dimmed');
    }

    const baseDifficulty = GameConfig.difficulties[this.difficulty];
    const badgeClass = this.activeMode === 'infinite' ? 'infinite' : this.difficulty;
    const badgeLabel = this.activeMode === 'infinite'
      ? '∞'
      : (baseDifficulty ? baseDifficulty.name : this.difficulty);

    const streakMarkup = this.activeMode === 'infinite'
      ? `<div class="header-streak" id="infiniteStreakBadge">
          <span class="streak-label">Streak</span>
          <span class="streak-value" id="infiniteStreakValue">${this.infiniteCurrentStreak}</span>
        </div>`
      : '';

    const streakHint = this.activeMode === 'infinite'
      ? `<div class="streak-note" id="infiniteStreakHint">
          Keep all stats at 70%+ to earn your daily streak bonus (24h cooldown).
          <button class="reset-streak-btn" id="resetStreakBtn" type="button" style="margin-left:10px;padding:4px 12px;font-size:0.8rem;background:#ff4444;color:white;border:none;border-radius:6px;cursor:pointer;">Reset Streak</button>
        </div>`
      : '';

    const musicPercent = Math.round(((typeof AudioManager !== 'undefined' && typeof AudioManager.musicVolume === 'number') ? AudioManager.musicVolume : 1) * 100);
    const sfxPercent = Math.round(((typeof AudioManager !== 'undefined' && typeof AudioManager.sfxVolume === 'number') ? AudioManager.sfxVolume : 1) * 100);

    container.innerHTML = `
      <div class="game-header">
        <div class="header-controls">
          <button class="pause-btn" id="gamePauseBtn" type="button">Pause</button>
          <div class="audio-toggle-wrap">
            <button class="audio-btn" id="gameAudioToggle" type="button">Audio</button>
            <div class="audio-panel" id="gameAudioPanel" hidden>
              <div class="audio-control">
                <label>Music: <span id="gameMusicValue">${musicPercent}%</span></label>
                <input type="range" id="gameMusicSlider" min="0" max="100" value="${musicPercent}" oninput="AudioManager.setMusicVolume(this.value); document.getElementById('gameMusicValue').textContent = this.value + '%';">
              </div>
              <div class="audio-control">
                <label>SFX: <span id="gameSfxValue">${sfxPercent}%</span></label>
                <input type="range" id="gameSfxSlider" min="0" max="100" value="${sfxPercent}" oninput="AudioManager.setSfxVolume(this.value); document.getElementById('gameSfxValue').textContent = this.value + '%';">
              </div>
            </div>
          </div>
          <button class="reset-btn" id="gameResetBtn" type="button">Reset</button>
          <button class="home-btn" id="gameHomeBtn" type="button">Menu</button>
        </div>
        <div class="header-status">
          <div class="difficulty-indicator ${badgeClass}">
            ${badgeLabel}
          </div>
          ${streakMarkup}
          <div class="session-timer" id="sessionTimer">
            <span class="timer-label">Alive</span>
            <span class="timer-value" id="sessionTimerValue">00:00</span>
          </div>
          <div class="streak-toast" id="infiniteStreakToast">
            <span class="streak-toast__title">Streak Bonus</span>
            <span class="streak-toast__value" id="infiniteStreakToastValue">+1</span>
          </div>
        </div>
      </div>
      <div class="game-body">
        <div class="pet-container" id="petContainer">
          <div class="pet-stage" id="petStage">
            <div class="pet-stage-light"></div>
            <div class="pet-dialogue" id="petDialogue">
              <div class="speech-bubble anchored" id="petSpeechBubble"></div>
            </div>
            <div class="pet-stage-floor" id="petStageFloor"></div>
          </div>
        </div>
        <div class="pet-stats-panel">
          <div class="stats-container">
            <div class="stat-bar" data-stat="hunger">
              <span class="stat-label">Hunger</span>
              <div class="stat-progress">
                <div class="stat-fill hunger-fill" id="hungerFill"></div>
              </div>
              <span class="stat-value" id="hungerValue">${Math.round(this.pet.hunger)}</span>
            </div>
            <div class="stat-bar" data-stat="sleep">
              <span class="stat-label">Sleep</span>
              <div class="stat-progress">
                <div class="stat-fill sleep-fill" id="sleepFill"></div>
              </div>
              <span class="stat-value" id="sleepValue">${Math.round(this.pet.sleep)}</span>
            </div>
            <div class="stat-bar" data-stat="happiness">
              <span class="stat-label">Fun</span>
              <div class="stat-progress">
                <div class="stat-fill happy-fill" id="happinessFill"></div>
              </div>
              <span class="stat-value" id="happinessValue">${Math.round(this.pet.happiness)}</span>
            </div>
          </div>
          ${streakHint}
        </div>
      </div>
      <div class="activities-divider">Pick an activity</div>
      <div class="action-buttons">
        <button class="action-btn" id="feedActionBtn" type="button">Feed</button>
        <button class="action-btn" id="sleepActionBtn" type="button">Nap</button>
        <button class="action-btn" id="playActionBtn" type="button">Play</button>
        <button class="action-btn" id="cleanActionBtn" type="button">Clean</button>
      </div>
      <div class="minigame-container" id="minigameContainer"></div>
    `;

    this.cacheUIElements();
    this.updateAllStatDisplays();
    this.updateCriticalState();
    this.updateStreakDisplay(this.infiniteCurrentStreak, { animate: false });
    this.updateStreakHint();
    if (!this.tutorialAutoStarted && this.difficulty === 'tutorial') {
      this.tutorialAutoStarted = true;
      setTimeout(() => {
        try {
          this.showTutorial();
        } catch (error) {
          console.warn('GameController: tutorial auto-start failed', error);
        }
      }, 350);
    }
  },

  cacheUIElements() {
    this.ui = {
      container: document.getElementById('gameContainer'),
      pauseBtn: document.getElementById('gamePauseBtn'),
      pauseOverlay: null,
      audioToggle: document.getElementById('gameAudioToggle'),
      audioPanel: document.getElementById('gameAudioPanel'),
      resetBtn: document.getElementById('gameResetBtn'),
      homeBtn: document.getElementById('gameHomeBtn'),
      sessionTimerValue: document.getElementById('sessionTimerValue'),
      hungerValue: document.getElementById('hungerValue'),
      hungerFill: document.getElementById('hungerFill'),
      sleepValue: document.getElementById('sleepValue'),
      sleepFill: document.getElementById('sleepFill'),
      happinessValue: document.getElementById('happinessValue'),
      happinessFill: document.getElementById('happinessFill'),
      petContainer: document.getElementById('petContainer'),
      minigameContainer: document.getElementById('minigameContainer'),
      streakBadge: document.getElementById('infiniteStreakBadge'),
      streakValue: document.getElementById('infiniteStreakValue'),
      streakHint: document.getElementById('infiniteStreakHint'),
      streakToast: document.getElementById('infiniteStreakToast'),
      streakToastValue: document.getElementById('infiniteStreakToastValue'),
      tutorialBtn: document.getElementById('tutorialLaunchBtn'),
      feedBtn: document.getElementById('feedActionBtn'),
      sleepBtn: document.getElementById('sleepActionBtn'),
      playBtn: document.getElementById('playActionBtn'),
      cleanBtn: document.getElementById('cleanActionBtn')
    };

    if (this.ui.pauseBtn) {
      this.ui.pauseBtn.onclick = () => this.pauseGame();
    }
    if (this.ui.audioToggle) {
      this.ui.audioToggle.onclick = () => this.toggleAudioSettings();
    }
    if (this.ui.resetBtn) {
      this.ui.resetBtn.onclick = () => this.resetPet();
    }
    if (this.ui.homeBtn) {
      this.ui.homeBtn.onclick = () => this.returnToMenuFromGame();
    }
    if (this.ui.feedBtn) {
      this.ui.feedBtn.onclick = () => this.startFeedMinigame();
    }
    if (this.ui.sleepBtn) {
      this.ui.sleepBtn.onclick = () => this.startSleepMinigame();
    }
    if (this.ui.playBtn) {
      this.ui.playBtn.onclick = () => this.startPlayMinigame();
    }
    if (this.ui.cleanBtn) {
      this.ui.cleanBtn.onclick = () => this.cleanPetArea();
    }
    if (this.ui.tutorialBtn) {
      this.ui.tutorialBtn.onclick = () => this.showTutorial();
    }
    if (this.ui.streakToast) {
      this.ui.streakToast.classList.remove('visible');
    }
  },

  startGameLoop() {
    this.stopGameLoop();

    if (!this.pet) {
      return;
    }

    // Use activeMode for infinite, otherwise use difficulty
    const difficultyKey = this.activeMode === 'infinite' ? 'infinite' : this.difficulty;
    const config = GameConfig.difficulties[difficultyKey] || GameConfig.difficulties.pikmin;
    const baseRate = config && typeof config.statDecayRate === 'number' ? config.statDecayRate : 0.3;
    this.lastTickTime = Date.now();

    this.gameLoop = setInterval(() => {
      if (!this.pet) {
        return;
      }

      if (!this.isPaused) {
        this.updateSessionTimer();
      }

      if (this.isGameOver || this.statDecayPaused || this.isPaused) {
        this.pet.lastUpdate = Date.now();
        return;
      }

      const now = Date.now();
      const deltaMs = now - this.lastTickTime;
      this.lastTickTime = now;
      this.pet.lastUpdate = now;

      const deltaMinutes = deltaMs / 60000;
      if (deltaMinutes <= 0) {
        return;
      }

      this.applyDecayTick(deltaMinutes, baseRate);
      this.updateAfterTick();
    }, 1000);
  },

  stopGameLoop() {
    if (this.gameLoop) {
      clearInterval(this.gameLoop);
      this.gameLoop = null;
    }
  },

  startSessionTimer() {
    this.stopSessionTimer();
    this.updateSessionTimer();
    this.sessionTimerInterval = setInterval(() => this.updateSessionTimer(), 1000);
  },

  stopSessionTimer() {
    if (this.sessionTimerInterval) {
      clearInterval(this.sessionTimerInterval);
      this.sessionTimerInterval = null;
    }
  },

  updateSessionTimer() {
    if (!this.ui || !this.ui.sessionTimerValue || !this.gameStartTime) {
      return;
    }

    // Don't update timer display if paused
    if (this.isPaused) {
      return;
    }

    const endTime = this.isGameOver && this.gameOverTime ? this.gameOverTime : Date.now();
    const elapsedMs = Math.max(0, endTime - this.gameStartTime);
    const totalSeconds = Math.floor(elapsedMs / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const formatted = hours > 0
      ? `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
      : `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    this.ui.sessionTimerValue.textContent = formatted;
  },

  pauseStatDecay() {
    this.statPauseDepth += 1;
    if (this.statPauseDepth < 0) {
      this.statPauseDepth = 0;
    }
    this.statDecayPaused = this.statPauseDepth > 0;
  },

  resumeStatDecay(force = false) {
    if (force) {
      this.statPauseDepth = 0;
    } else if (this.statPauseDepth > 0) {
      this.statPauseDepth -= 1;
    }

    if (this.statPauseDepth <= 0) {
      this.statPauseDepth = 0;
      this.statDecayPaused = false;
      this.lastTickTime = Date.now();
      if (this.pet) {
        this.pet.lastUpdate = this.lastTickTime;
      }
    }
  },

// Replace the existing pauseGame() method with this fixed version

pauseGame() {
  if (this.isGameOver) {
    return;
  }

  if (!this.isPaused) {
    this.isPaused = true;
    this.pauseStatDecay();
    this.pauseStartTime = Date.now();

    // Create the pause overlay
    const overlay = document.createElement('div');
    overlay.className = 'game-pause-overlay';
    
    // Fixed CSS - ensure it covers the full container and is clickable
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background: rgba(12, 6, 32, 0.85);
      color: #f8f4ff;
      font-size: 1.8rem;
      font-weight: 600;
      z-index: 9999;
      text-align: center;
      gap: 18px;
      padding: 20px;
      cursor: pointer;
    `;
    
    overlay.innerHTML = `
      <div style="pointer-events: none;">Game paused</div>
      <div style="font-size: 1rem; font-weight: 400; pointer-events: none;">
        Click anywhere or press Resume to continue caring for your pet.
      </div>
    `;
    
    // Add click handler to the overlay itself to unpause
    overlay.addEventListener('click', (e) => {
      // Only unpause if clicking on the overlay background, not the text
      if (e.target === overlay) {
        this.resumeGame();
      }
    });
    
    // Add to document body instead of container for full coverage
    document.body.appendChild(overlay);
    this.ui.pauseOverlay = overlay;
    
    if (this.ui && this.ui.pauseBtn) {
      this.ui.pauseBtn.textContent = 'Resume';
    }
  } else {
    this.resumeGame();
  }
},

// Add this new method to handle resuming (for cleaner code)
resumeGame() {
  if (!this.isPaused) {
    return;
  }

  this.isPaused = false;
  this.resumeStatDecay();

  // Add the paused time to gameStartTime so it doesn't count
  if (this.pauseStartTime) {
    const pausedDuration = Date.now() - this.pauseStartTime;
    this.gameStartTime += pausedDuration;
    this.pauseStartTime = null;
  }

  if (this.ui && this.ui.pauseOverlay) {
    this.ui.pauseOverlay.remove();
    this.ui.pauseOverlay = null;
  }

  if (this.ui && this.ui.pauseBtn) {
    this.ui.pauseBtn.textContent = 'Pause';
  }
},

  toggleAudioSettings() {
    if (!this.ui || !this.ui.audioPanel) {
      return;
    }
    if (this.ui.audioPanel.hasAttribute('hidden')) {
      this.ui.audioPanel.removeAttribute('hidden');
    } else {
      this.ui.audioPanel.setAttribute('hidden', 'hidden');
    }
  },

  resetPet() {
    if (this.isGameOver) {
      return;
    }

    // Set all stats to 0 to trigger game over
    this.pet.hunger = 0;
    this.pet.sleep = 0;
    this.pet.happiness = 0;

    this.updateAllStatDisplays();
    this.triggerGameOver();
  },

  returnToMenuFromGame() {
    this.stopGameLoop();
    this.stopSessionTimer();
    this.resumeStatDecay(true);
    this.isPaused = false;
    this.currentMinigame = null;

    try {
      if (typeof PetSystem !== 'undefined' && typeof PetSystem.cleanup === 'function') {
        PetSystem.cleanup();
      }
    } catch (error) {
      console.warn('PetSystem cleanup failed during exit', error);
    }

    this.teardownTutorial({ resume: false });

    if (this.ui && this.ui.pauseOverlay) {
      this.ui.pauseOverlay.remove();
      this.ui.pauseOverlay = null;
    }

    if (typeof AudioManager !== 'undefined') {
      AudioManager.stopAllMusic();
      if (typeof AudioManager.restartIntroMusic === 'function') {
        AudioManager.restartIntroMusic();
      }
    }

    if (typeof App !== 'undefined' && App && typeof App.transitionToScreen === 'function') {
      App.transitionToScreen('game', 'menu');
    }
  },

  startFeedMinigame() {
    if (this.isGameOver || this.currentMinigame) {
      return;
    }
    if (typeof FeedMinigame !== 'undefined' && typeof FeedMinigame.start === 'function') {
      FeedMinigame.start();
    }
  },

  startSleepMinigame() {
    if (this.isGameOver || this.currentMinigame) {
      return;
    }
    if (typeof SleepMinigame !== 'undefined' && typeof SleepMinigame.start === 'function') {
      SleepMinigame.start();
    }
  },

  startPlayMinigame() {
    if (this.isGameOver || this.currentMinigame) {
      return;
    }
    if (typeof PlayMinigame !== 'undefined' && typeof PlayMinigame.start === 'function') {
      PlayMinigame.start();
    }
  },

  cleanPetArea() {
    if (typeof PetSystem !== 'undefined' && typeof PetSystem.cleanPoops === 'function') {
      PetSystem.cleanPoops();
    }
    this.updatePoopPenalty(0);
    this.updateCriticalState();
    if (this.tutorialState && this.tutorialState.active) {
      document.dispatchEvent(new CustomEvent('tutorial:cleaned'));
    }
  },

  updatePoopPenalty(count) {
    const number = Math.max(0, Number(count) || 0);
    this.poopPenalty = Math.max(0, Math.min(5, number));
  },

  applyDecayTick(deltaMinutes, baseRate) {
    if (!this.pet || baseRate <= 0 || deltaMinutes <= 0) {
      return;
    }

    const penaltyMultiplier = 1 + (this.poopPenalty * 0.35);
    const modeMultiplier = this.activeMode === 'infinite' ? 0.75 : 1;
    const decayUnit = baseRate * deltaMinutes * 12 * penaltyMultiplier * modeMultiplier;

    this.pet.hunger = this.clampStat(this.pet.hunger - decayUnit);
    this.pet.sleep = this.clampStat(this.pet.sleep - decayUnit * 0.9);
    this.pet.happiness = this.clampStat(this.pet.happiness - decayUnit * 0.7);

    const averageSupport = (this.pet.hunger + this.pet.sleep) / 2;
    if (this.pet.happiness > averageSupport + 15) {
      this.pet.happiness = Math.max(averageSupport + 15, this.pet.happiness - decayUnit * 0.5);
    }
  },

  updateAfterTick() {
    this.updateAllStatDisplays();
    this.updateMoodVisuals();
    this.updateCriticalState();
    this.checkGameOver();

    if (this.activeMode === 'infinite') {
      this.persistInfiniteStats();
      this.evaluateInfiniteStreak({ suppressToast: false });
    }
  },

  updateAllStatDisplays() {
    ['hunger', 'sleep', 'happiness'].forEach((stat) => this.updateStatDisplay(stat));
  },

  updateStatDisplay(stat) {
    if (!this.pet || !this.ui) {
      return;
    }

    const value = Math.round(this.clampStat(this.pet[stat]));
    const valueKey = `${stat}Value`;
    const fillKey = `${stat}Fill`;

    if (this.ui[valueKey]) {
      this.ui[valueKey].textContent = value;
    }
    if (this.ui[fillKey]) {
      this.ui[fillKey].style.width = `${value}%`;
    }
  },

  updateMoodVisuals() {
    if (typeof PetSystem !== 'undefined' && typeof PetSystem.updateMood === 'function') {
      try {
        PetSystem.updateMood();
      } catch (error) {
        console.warn('PetSystem.updateMood failed', error);
      }
    }
  },

  updateCriticalState() {
    if (!this.ui || !this.ui.petContainer || !this.pet) {
      return;
    }

    const threshold = GameConfig.stats.criticalThreshold || 20;
    const isCritical = this.pet.hunger <= threshold || this.pet.sleep <= threshold || this.pet.happiness <= threshold;
    this.ui.petContainer.classList.toggle('critical', Boolean(isCritical));
  },

  updateStat(stat, delta) {
    if (!this.pet || typeof delta !== 'number') {
      return 0;
    }

    const previousValue = this.pet[stat];
    const newValue = this.clampStat(previousValue + delta);
    this.pet[stat] = newValue;

    this.updateStatDisplay(stat);
    this.updateMoodVisuals();
    this.updateCriticalState();
    this.checkGameOver();

    if (typeof PetSystem !== 'undefined' && typeof PetSystem.reactToStatChange === 'function') {
      try {
        PetSystem.reactToStatChange(stat, newValue - previousValue);
      } catch (error) {
        console.warn('PetSystem.reactToStatChange failed', error);
      }
    }

    if (this.activeMode === 'infinite') {
      this.persistInfiniteStats();
      this.evaluateInfiniteStreak({ suppressToast: false });
    }

    return newValue;
  },

  clampStat(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) {
      return 0;
    }
    return Math.max(0, Math.min(GameConfig.stats.maxValue, number));
  },

  checkGameOver() {
    if (!this.pet || this.isGameOver) {
      return;
    }

    if (this.pet.hunger <= 0 || this.pet.sleep <= 0 || this.pet.happiness <= 0) {
      this.triggerGameOver();
    }
  },

  triggerGameOver() {
    if (this.isGameOver) {
      return;
    }

    this.isGameOver = true;
    this.gameOverTime = Date.now();
    this.stopGameLoop();
    this.updateSessionTimer();
    this.resumeStatDecay(true);

    // Clear local storage if infinite mode
    if (this.activeMode === 'infinite' && typeof StateStore !== 'undefined') {
      try {
        if (typeof StateStore.clearInfiniteData === 'function') {
          StateStore.clearInfiniteData();
        } else if (typeof localStorage !== 'undefined') {
          // Fallback: clear infinite-related storage manually
          localStorage.removeItem('infiniteStats');
          localStorage.removeItem('infiniteStreak');
          localStorage.removeItem('infiniteLastCheckIn');
          localStorage.removeItem('infiniteAppearance');
        }
      } catch (error) {
        console.warn('GameController: unable to clear infinite storage', error);
      }
    }

    // Store current volumes to restore later
    this.savedVolumes = {
      music: typeof AudioManager !== 'undefined' ? AudioManager.musicVolume : 1,
      sfx: typeof AudioManager !== 'undefined' ? AudioManager.sfxVolume : 1
    };

    // Mute all audio sources
    if (typeof AudioManager !== 'undefined') {
      AudioManager.setMusicVolume(0);
      AudioManager.setSfxVolume(0);
    }

    // Mute lobby music specifically
    const lobbyMusic = document.getElementById('lobbyMusic');
    if (lobbyMusic) {
      lobbyMusic.volume = 0;
    }

    // Mute pet speech
    if (typeof PetSystem !== 'undefined' && PetSystem.speechAudio) {
      PetSystem.speechAudio.volume = 0;
    }

    this.showGameOverOverlay();

    if (!this.deathSound) {
      try {
        this.deathSound = new Audio('assets/audio/so_sorry_i_died.mp3');
        this.deathSound.volume = this.savedVolumes.sfx;
      } catch (error) {
        console.warn('GameController: unable to prepare death sound', error);
      }
    }

    if (this.deathSound) {
      this.deathSound.currentTime = 0;
      this.deathSound.play().catch(() => {});
    }
  },

  restoreAudioLevels() {
    // Stop the death sound
    if (this.deathSound) {
      try {
        this.deathSound.pause();
        this.deathSound.currentTime = 0;
      } catch (error) {
        console.warn('Could not stop death sound', error);
      }
    }

    if (!this.savedVolumes) {
      return;
    }

    // Restore volume levels
    if (typeof AudioManager !== 'undefined') {
      AudioManager.setMusicVolume(this.savedVolumes.music * 100);
      AudioManager.setSfxVolume(this.savedVolumes.sfx * 100);
    }

    // Restore lobby music volume
    const lobbyMusic = document.getElementById('lobbyMusic');
    if (lobbyMusic && typeof AudioManager !== 'undefined') {
      lobbyMusic.volume = AudioManager.musicVolume;
    }

    this.savedVolumes = null;
  },

  showGameOverOverlay() {
    if (!this.ui || !this.ui.container) {
      return;
    }

    const existing = document.querySelector('.death-screen-overlay');
    if (existing) {
      return;
    }

    // Calculate survival time
    const elapsedMs = this.gameOverTime - this.gameStartTime;
    const totalSeconds = Math.floor(elapsedMs / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const survivalTimeFormatted = hours > 0
      ? `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
      : `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    const overlay = document.createElement('div');
    overlay.className = 'death-screen-overlay';
    overlay.innerHTML = `
      <div class="death-screen-content">
        <div class="death-icon-sprite"></div>
        <h1>Rest in Peace</h1>
        <p class="death-message">Your pet has passed away. They lived a good life while you cared for them.</p>
        <div class="survival-time">
          <span class="time-label">Time Survived</span>
          <div class="time-value">${survivalTimeFormatted}</div>
        </div>
        <div class="death-stats">
          <div class="final-stat">Hunger: ${Math.round(this.pet.hunger)}</div>
          <div class="final-stat">Sleep: ${Math.round(this.pet.sleep)}</div>
          <div class="final-stat">Fun: ${Math.round(this.pet.happiness)}</div>
        </div>
        <div>
          <button type="button" class="restart-btn">Try Again</button>
          <button type="button" class="menu-btn">Main Menu</button>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    // Trigger show animation
    setTimeout(() => {
      overlay.classList.add('show');
    }, 50);

    const restartBtn = overlay.querySelector('.restart-btn');
    const menuBtn = overlay.querySelector('.menu-btn');

    if (restartBtn) {
      restartBtn.onclick = () => {
        this.restoreAudioLevels();
        overlay.remove();
        // Restart with the same difficulty
        this.init(this.difficulty, { mode: this.activeMode, petTypeOverride: this.pet.type });
      };
    }

    if (menuBtn) {
      menuBtn.onclick = () => {
        this.restoreAudioLevels();
        overlay.remove();
        this.returnToMenuFromGame();
      };
    }
  },

  persistInfiniteStats(force = false) {
    if (this.activeMode !== 'infinite' || !this.pet || typeof StateStore === 'undefined' || typeof StateStore.updateStats !== 'function') {
      return;
    }

    const now = Date.now();
    if (!force && now - this.infiniteLastPersist < 5000) {
      return;
    }

    try {
      if (!StateStore.isReady || StateStore.isReady()) {
        StateStore.updateStats({
          hunger: this.pet.hunger,
          sleep: this.pet.sleep,
          happiness: this.pet.happiness
        }, { force });
        this.infiniteLastPersist = now;
      }
    } catch (error) {
      console.warn('GameController: unable to persist infinite stats', error);
    }
  },

  evaluateInfiniteStreak(options = {}) {
    if (this.activeMode !== 'infinite' || !this.pet || typeof StateStore === 'undefined' || typeof StateStore.evaluateStreak !== 'function') {
      return null;
    }

    const suppressToast = Boolean(options && options.suppressToast);

    try {
      if (!StateStore.isReady || StateStore.isReady()) {
        const result = StateStore.evaluateStreak({
          hunger: this.pet.hunger,
          sleep: this.pet.sleep,
          happiness: this.pet.happiness
        });

        if (result) {
          this.infiniteCurrentStreak = Math.max(0, Number(result.streak) || 0);
          this.infiniteCooldownMs = Math.max(0, Number(result.cooldownMs) || 0);
          this.updateStreakDisplay(this.infiniteCurrentStreak, { animate: Boolean(result.awarded) });
          this.updateStreakHint(result);

          if (result.awarded && this.lastStreakNotified !== this.infiniteCurrentStreak && !suppressToast) {
            this.lastStreakNotified = this.infiniteCurrentStreak;
            this.showStreakToast(this.infiniteCurrentStreak);

            // Show extreme unlock popup if this is their first streak
            if (this.infiniteCurrentStreak === 1) {
              this.queueExtremeUnlockPopup();
            }
          }
        }

        return result;
      }
    } catch (error) {
      console.warn('GameController: unable to evaluate infinite streak', error);
    }
    return null;
  },

  updateStreakDisplay(streakValue, options = {}) {
    if (!this.ui || !this.ui.streakValue) {
      return;
    }

    const oldValue = parseInt(this.ui.streakValue.textContent) || 0;
    const newValue = Math.max(0, Number(streakValue) || 0);
    this.ui.streakValue.textContent = String(newValue);

    // Add flame animation if streak increased
    if (options.animate && newValue > oldValue) {
      this.ui.streakValue.classList.remove('flame-ignite', 'flame-flicker');
      void this.ui.streakValue.offsetWidth; // Force reflow
      this.ui.streakValue.classList.add('flame-ignite');

      // Add continuous flicker after ignite animation
      setTimeout(() => {
        this.ui.streakValue.classList.remove('flame-ignite');
        this.ui.streakValue.classList.add('flame-flicker');

        // Remove flicker after a few seconds
        setTimeout(() => {
          this.ui.streakValue.classList.remove('flame-flicker');
        }, 3000);
      }, 800);
    }

    if (options && options.animate && this.ui.streakBadge) {
      this.ui.streakBadge.classList.add('streak-pulse');
      setTimeout(() => {
        if (this.ui && this.ui.streakBadge) {
          this.ui.streakBadge.classList.remove('streak-pulse');
        }
      }, 1200);
    }
  },

  updateStreakHint(result) {
    if (!this.ui || !this.ui.streakHint) {
      return;
    }

    if (this.activeMode !== 'infinite') {
      this.ui.streakHint.textContent = '';
      return;
    }

    const hint = this.ui.streakHint;
    const defaultMessage = 'Keep all stats at 70%+ to earn your daily streak bonus (24h cooldown).';

    if (!result) {
      if (this.infiniteCooldownMs > 0) {
        hint.textContent = `Next bonus in ${this.formatCooldownDuration(this.infiniteCooldownMs)}`;
        hint.classList.remove('ready');
      } else {
        hint.textContent = defaultMessage;
        hint.classList.remove('ready');
      }
      return;
    }

    if (!result.allHigh) {
      hint.textContent = defaultMessage;
      hint.classList.remove('ready');
      return;
    }

    if (result.cooldownMs > 0) {
      hint.textContent = `Bonus claimed! Come back in ${this.formatCooldownDuration(result.cooldownMs)}`;
      hint.classList.remove('ready');
      return;
    }

    if (result.awarded) {
      hint.textContent = 'Bonus collected! Keep the streak going tomorrow.';
      hint.classList.add('ready');
    } else {
      hint.textContent = 'Stats ready! Keeping them high will secure your bonus.';
      hint.classList.add('ready');
    }
  },

  formatCooldownDuration(ms) {
    if (!Number.isFinite(ms) || ms <= 0) {
      return '0s';
    }
    const totalSeconds = Math.ceil(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    if (minutes > 0) {
      return `${minutes}m ${seconds}s`;
    }
    return `${seconds}s`;
  },

  showStreakToast(streakValue) {
    if (!this.ui || !this.ui.streakToast || !this.ui.streakToastValue) {
      return;
    }

    this.ui.streakToastValue.textContent = `+${streakValue}`;
    this.ui.streakToast.classList.add('visible');

    if (this.streakToastTimer) {
      clearTimeout(this.streakToastTimer);
    }

    this.streakToastTimer = setTimeout(() => {
      if (this.ui && this.ui.streakToast) {
        this.ui.streakToast.classList.remove('visible');
      }
      this.streakToastTimer = null;
    }, 3200);
  },

  queueExtremeUnlockPopup() {
    // Queue the popup to show after returning to lobby (not during minigame)
    this.pendingExtremeUnlock = true;
    this.checkAndShowExtremeUnlock();
  },

  checkAndShowExtremeUnlock() {
    // Only show if not in a minigame and popup is pending
    if (this.pendingExtremeUnlock && !this.currentMinigame) {
      this.showExtremeUnlockPopup();
      this.pendingExtremeUnlock = false;
    }
  },

  showExtremeUnlockPopup() {
    const popup = document.getElementById('extremeUnlockPopup');
    const btn = document.getElementById('extremeUnlockBtn');

    if (!popup || !btn) return;

    popup.style.display = 'flex';

    const closePopup = () => {
      popup.style.display = 'none';
      btn.removeEventListener('click', closePopup);
    };

    btn.addEventListener('click', closePopup);
  },

  showTutorial() {

    if (this.tutorialState && this.tutorialState.active) {

      return;

    }



    const steps = [

      {

        key: 'intro',

        selector: '#petStage',

        content: `

          <h2>Chiikawa's Cozy Tour</h2>

          <p>Hi! I'm Chiikawa from the hit manga series 'Chiikawa'. Let's look at everything you can do to keep your pet nice and healthy. Together with me! Chiikawa from the hit series 'Chiikawa'</p>

        `

      },

      {

        key: 'feed',

        selector: '#feedActionBtn',

        content: `

          <h2>Glorified Gambling</h2>

          <p>Feeding Keeps the Hunger Stat up! Unlike other Minigames there's no strategy to this one! Makes you wonder why I'm starting with this...</p>

        `,

        practice: {

          label: 'Try Feed Game',

          workingLabel: 'Launching...',

          action: () => this.startFeedMinigame(),

          waitEvent: 'tutorial:minigameEnd',

          waitFilter: (event) => event && event.detail && event.detail.minigame === 'feed',

          suspendOverlay: true

        }

      },

      {

        key: 'sleep',

        selector: '#sleepActionBtn',

        content: `

          <h2>Power Nap</h2>

          <p>Counting sheep refills energy. Try the Speed Up button if you want everything twice as fast. Rewards climb to 1.5x!</p>

        `,

        practice: {

          label: 'Try Sleep Game',

          workingLabel: 'Launching...',

          action: () => this.startSleepMinigame(),

          waitEvent: 'tutorial:minigameEnd',

          waitFilter: (event) => event && event.detail && event.detail.minigame === 'sleep',

          suspendOverlay: true

        }

      },

      {

        key: 'play',

        selector: '#playActionBtn',

        content: `

          <h2>Play Time</h2>

          <p>Fun keeps happiness high. Let's hop into the play game so you can feel the timing.</p>

        `,

        practice: {

          label: 'Try Play Game',

          workingLabel: 'Launching...',

          action: () => this.startPlayMinigame(),

          waitEvent: 'tutorial:minigameEnd',

          waitFilter: (event) => event && event.detail && event.detail.minigame === 'play',

          suspendOverlay: true

        }

      },

      {

        key: 'clean',

        selector: '#cleanActionBtn',

        content: `

          <h2>It smell like you farted</h2>

          <p>Poops slow recovery or flatout make the game harder. I'll make a little mess - tap Clean to tidy up.</p>

        `,

        practice: {

          label: 'Create A Mess',

          workingLabel: 'Making mess...',

          action: () => {

            if (typeof PetSystem !== 'undefined' && typeof PetSystem.createPoop === 'function') {

              PetSystem.createPoop();

              setTimeout(() => {

                if (typeof PetSystem !== 'undefined' && typeof PetSystem.createPoop === 'function') {

                  PetSystem.createPoop();

                }

              }, 600);

            }

          },

          waitEvent: 'tutorial:cleaned',

          suspendOverlay: true

        }

      },

      {

        key: 'wrap',

        selector: '#petStage',

        content: `

          <h2>You've Got This!</h2>

          <p>Visit Feed, Nap, Play, and Clean each session. I hope you enjoy, ive been Chiikawa from the hit manga series 'Chiikawa'! Whenever you are ready to return back to the main menu click the 'Menu' button above the pet's cage</p>

        `

      }

    ];



    const overlay = document.createElement('div');

    overlay.className = 'tutorial-overlay tutorial-kuchi';

    overlay.style.pointerEvents = 'auto';

    overlay.innerHTML = `

      <div class="tutorial-backdrop" data-tutorial-backdrop="true"></div>

      <div class="tutorial-content">

        <button type="button" class="tutorial-close" aria-label="Skip tutorial">&times;</button>

        <div class="tutorial-body">

          <img src="assets/sprites/chikawa_idle.png" alt="Chikawa presenting" class="tutorial-kuchi-avatar">

          <div class="tutorial-text">

            <div class="tutorial-progress-label" id="tutorialProgressLabel"></div>

            <div class="tutorial-message" id="tutorialMessage"></div>

            <div class="tutorial-actions">

              <button type="button" class="tutorial-back" disabled>Back</button>

              <button type="button" class="tutorial-practice" style="visibility: hidden;">Show Me</button>

              <button type="button" class="tutorial-next">Next</button>

            </div>

          </div>

        </div>

        <div class="tutorial-progress" id="tutorialProgressDots"></div>

      </div>

    `;



    document.body.appendChild(overlay);



    const progressContainer = overlay.querySelector('#tutorialProgressDots');

    if (progressContainer) {

      progressContainer.innerHTML = steps.map((_, index) => `<span class="tutorial-progress-step" data-step="${index}"></span>`).join('');

    }



    const messageEl = overlay.querySelector('#tutorialMessage');

    const progressLabel = overlay.querySelector('#tutorialProgressLabel');

    const backBtn = overlay.querySelector('.tutorial-back');

    const nextBtn = overlay.querySelector('.tutorial-next');

    const practiceBtn = overlay.querySelector('.tutorial-practice');

    const closeBtn = overlay.querySelector('.tutorial-close');



    this.pauseStatDecay();

    const gameScreen = document.querySelector('.game-screen');

    if (gameScreen) {

      gameScreen.classList.add('tutorial-dimmed');

    }



    this.tutorialState = {

      active: true,

      overlay,

      steps,

      index: 0,

      messageEl,

      progressLabel,

      backBtn,

      nextBtn,

      practiceBtn,

      progressContainer,

      highlightTarget: null,

      pendingHandler: null,

      pendingEvent: null,

      pendingTimeout: null

    };



    if (backBtn) {

      backBtn.onclick = () => this.updateTutorialStep(this.tutorialState.index - 1);

    }

    if (nextBtn) {

      nextBtn.onclick = () => this.updateTutorialStep(this.tutorialState.index + 1);

    }

    if (practiceBtn) {

      practiceBtn.onclick = () => {

        const step = this.tutorialState.steps[this.tutorialState.index];

        if (!step || !step.practice || practiceBtn.disabled) {

          return;

        }



        practiceBtn.disabled = true;

        practiceBtn.style.pointerEvents = 'none';

        practiceBtn.textContent = step.practice.workingLabel || 'Working...';



        const shouldSuspend = step.practice.suspendOverlay !== false && (Boolean(step.practice.waitEvent) || Boolean(step.practice.autoAdvanceDelay));

        if (shouldSuspend) {

          this.setTutorialOverlaySuspended(true);

        }



        try {

          step.practice.action();

        } catch (error) {

          console.warn('Tutorial practice action failed', error);

        }



        if (step.practice.waitEvent) {

          const handler = (event) => {

            if (step.practice.waitFilter && !step.practice.waitFilter(event)) {

              return;

            }

            document.removeEventListener(step.practice.waitEvent, handler);

            if (!this.tutorialState) {

              return;

            }

            this.tutorialState.pendingHandler = null;

            this.tutorialState.pendingEvent = null;

            this.setTutorialOverlaySuspended(false);

            this.updateTutorialStep(this.tutorialState.index + 1);

          };

          document.addEventListener(step.practice.waitEvent, handler);

          this.tutorialState.pendingHandler = handler;

          this.tutorialState.pendingEvent = step.practice.waitEvent;

        } else if (step.practice.autoAdvanceDelay) {

          const timeout = setTimeout(() => {

            if (!this.tutorialState) {

              return;

            }

            this.setTutorialOverlaySuspended(false);

            this.tutorialState.pendingTimeout = null;

            this.updateTutorialStep(this.tutorialState.index + 1);

          }, step.practice.autoAdvanceDelay);

          this.tutorialState.pendingTimeout = timeout;

        } else {

          this.setTutorialOverlaySuspended(false);

          practiceBtn.disabled = false;

          practiceBtn.style.pointerEvents = 'auto';

          practiceBtn.textContent = step.practice.label || 'Show Me';

        }

      };

    }

    if (closeBtn) {

      closeBtn.onclick = () => this.teardownTutorial({ resume: true });

    }



    overlay.addEventListener('click', (event) => {

      if (event.target && event.target.matches('[data-tutorial-backdrop]')) {

        this.teardownTutorial({ resume: true });

      }

    });



    this.updateTutorialStep(0);

  },



  teardownTutorial(options = {}) {

    if (!this.tutorialState) {

      return;

    }



    if (this.tutorialState.pendingHandler && this.tutorialState.pendingEvent) {

      document.removeEventListener(this.tutorialState.pendingEvent, this.tutorialState.pendingHandler);

    }

    if (this.tutorialState.pendingTimeout) {

      clearTimeout(this.tutorialState.pendingTimeout);

    }



    if (this.tutorialState.overlay && this.tutorialState.overlay.parentNode) {

      this.tutorialState.overlay.parentNode.removeChild(this.tutorialState.overlay);

    }



    const gameScreen = document.querySelector('.game-screen');

    if (gameScreen) {

      gameScreen.classList.remove('tutorial-dimmed');

    }



    this.clearTutorialHighlight();



    const shouldResume = !(options && options.resume === false);

    this.tutorialState = null;



    if (shouldResume && !this.isPaused && !this.isGameOver) {

      this.resumeStatDecay();

    }

  },



  setTutorialOverlaySuspended(isSuspended) {

    if (!this.tutorialState || !this.tutorialState.overlay) {

      return;

    }



    const overlay = this.tutorialState.overlay;

    const backdrop = overlay.querySelector('.tutorial-backdrop');

    const gameScreen = document.querySelector('.game-screen');



    if (isSuspended) {

      overlay.style.visibility = 'hidden';

      overlay.style.opacity = '0';

      overlay.style.pointerEvents = 'none';

      if (backdrop) {

        backdrop.style.display = 'none';

      }

      if (gameScreen) {

        gameScreen.classList.remove('tutorial-dimmed');

      }

    } else {

      overlay.style.visibility = '';

      overlay.style.opacity = '';

      overlay.style.pointerEvents = 'auto';

      if (backdrop) {

        backdrop.style.display = '';

      }

      if (gameScreen) {

        gameScreen.classList.add('tutorial-dimmed');

      }

      if (this.tutorialState.practiceBtn) {

        const step = this.tutorialState.steps[this.tutorialState.index];

        if (step && step.practice) {

          this.tutorialState.practiceBtn.disabled = false;

          this.tutorialState.practiceBtn.style.visibility = 'visible';

          this.tutorialState.practiceBtn.style.pointerEvents = 'auto';

          this.tutorialState.practiceBtn.textContent = step.practice.label || 'Show Me';

        } else {

          this.tutorialState.practiceBtn.disabled = true;

          this.tutorialState.practiceBtn.style.visibility = 'hidden';

          this.tutorialState.practiceBtn.style.pointerEvents = 'none';

        }

      }

    }

  },



  updateTutorialStep(index) {

    if (!this.tutorialState) {

      return;

    }



    const { steps } = this.tutorialState;



    if (index < 0) {

      index = 0;

    }



    if (index >= steps.length) {

      this.teardownTutorial({ resume: true });

      return;

    }



    if (this.tutorialState.pendingHandler && this.tutorialState.pendingEvent) {

      document.removeEventListener(this.tutorialState.pendingEvent, this.tutorialState.pendingHandler);

      this.tutorialState.pendingHandler = null;

      this.tutorialState.pendingEvent = null;

    }

    if (this.tutorialState.pendingTimeout) {

      clearTimeout(this.tutorialState.pendingTimeout);

      this.tutorialState.pendingTimeout = null;

    }



    this.tutorialState.index = index;

    const step = steps[index];



    if (this.tutorialState.progressContainer) {

      const dots = this.tutorialState.progressContainer.querySelectorAll('.tutorial-progress-step');

      dots.forEach((dot, dotIndex) => {

        dot.classList.toggle('active', dotIndex === index);

        dot.classList.toggle('complete', dotIndex < index);

      });

    }



    if (this.tutorialState.progressLabel) {

      this.tutorialState.progressLabel.textContent = `Step ${index + 1} of ${steps.length}`;

    }



    if (this.tutorialState.messageEl) {

      this.tutorialState.messageEl.innerHTML = step.content;

    }



    if (this.tutorialState.backBtn) {

      this.tutorialState.backBtn.disabled = index === 0;

    }



    if (this.tutorialState.nextBtn) {

      this.tutorialState.nextBtn.textContent = index === steps.length - 1 ? 'Finish' : 'Next';

    }



    this.setTutorialOverlaySuspended(false);

    this.highlightTutorialTarget(step.selector);

  },



  highlightTutorialTarget(selector) {

    this.clearTutorialHighlight();



    if (!selector) {

      return;

    }



    const target = document.querySelector(selector);

    if (target) {

      target.classList.add('tutorial-highlighted');

      this.tutorialState.highlightTarget = target;

    }

  },



  clearTutorialHighlight() {

    if (this.tutorialState && this.tutorialState.highlightTarget) {

      this.tutorialState.highlightTarget.classList.remove('tutorial-highlighted');

      this.tutorialState.highlightTarget = null;

    }

  }

};







