﻿// js/difficulty.js - Difficulty selection controller

const INFINITE_PET_LABELS = {
  pikmin: 'Pikmin',
  kuchi: 'Kuchi',
  chikawa: 'Chikawa'
};

const DifficultyController = {
  selectedDifficulty: null,
  isTransitioning: false,
  transitionTimeout: null,
  infiniteModal: null,
  infiniteKeyHandler: null,
  
  init() {
    const difficultyCards = document.querySelectorAll('.difficulty-card');
    const backBtn = document.getElementById('backBtn');

    // Check streak and lock extreme mode if needed - wait for StateStore to be ready
    if (globalThis.StateStore && globalThis.StateStore.ready && typeof globalThis.StateStore.ready.then === 'function') {
      globalThis.StateStore.ready.then(() => this.updateExtremeLock());
    } else {
      this.updateExtremeLock();
    }

    // Add click handlers to difficulty cards
    difficultyCards.forEach(card => {
      card.addEventListener('click', (e) => {
        if (this.isTransitioning) return;

        // Check if kuchi mode is locked
        if (card.dataset.difficulty === 'kuchi' && card.classList.contains('locked')) {
          this.showSelectionFeedback('kuchi-locked', '🔒 Complete at least 1 Infinite Mode streak to unlock!');
          return;
        }

        this.selectDifficulty(card.dataset.difficulty, card);
      });

      // Add hover effect
      card.addEventListener('mouseenter', () => {
        // Optional: Add hover sound
      });
    });

    // Back button
    if (backBtn) {
      backBtn.addEventListener('click', () => {
        if (this.isTransitioning) return;
        this.goBack();
      });
    }

    // Update infinite card cooldown display
    this.updateInfiniteCooldownDisplay();
    // Update every second
    this.cooldownInterval = setInterval(() => this.updateInfiniteCooldownDisplay(), 1000);

    this.infiniteModal = document.getElementById('infiniteCharacterModal');
    if (this.infiniteModal) {
      this.infiniteOptionButtons = Array.from(this.infiniteModal.querySelectorAll('[data-pet]')) || [];
      this.infiniteStreakDisplay = this.infiniteModal.querySelector('[data-infinite-streak]');
      this.infiniteAppearanceDisplay = this.infiniteModal.querySelector('[data-infinite-appearance]');

      this.infiniteOptionButtons.forEach((button) => {
        button.addEventListener('click', () => this.startInfiniteRun(button.dataset.pet));
      });

      const closeElements = this.infiniteModal.querySelectorAll('[data-infinite-close]');
      closeElements.forEach((el) => el.addEventListener('click', () => this.closeInfiniteModal()));

      const refreshModalState = () => this.updateInfiniteModalState();
      if (globalThis.StateStore && globalThis.StateStore.ready && typeof globalThis.StateStore.ready.then === 'function') {
        globalThis.StateStore.ready.then(() => refreshModalState());
      } else {
        refreshModalState();
      }
    }
  },
  
  selectDifficulty(difficulty, cardElement) {
    this.isTransitioning = true;
    this.selectedDifficulty = difficulty;

    // Play select sound
    AudioManager.playSound('select');

    // Add selection animation to card
    cardElement.style.animation = 'none';
    setTimeout(() => {
      cardElement.style.animation = 'selectedPulse 0.5s ease';
    }, 10);

    if (difficulty === 'infinite') {
      this.showSelectionFeedback('infinite', 'Choose a buddy for Infinite Mode!');
      this.openInfiniteModal();
      this.isTransitioning = false;
      return;
    }

    // Show selection feedback
    this.showSelectionFeedback(difficulty);

    if (window.ScreenTransition) {
      clearTimeout(this.transitionTimeout);
      this.transitionTimeout = setTimeout(() => {
        ScreenTransition.play({ direction: 'forward' });
        this.transitionTimeout = null;
      }, 1000);
    }

    AudioManager.fadeOutIntroAndPlayTransition(() => {
      setTimeout(() => {
        console.log(`Starting game with ${difficulty} difficulty`);
        App.startGame(difficulty);

        setTimeout(() => {
          AudioManager.stopTransitionMusic();
        }, 1000);

        this.isTransitioning = false;
      }, 600);
    });
  },
  
  showSelectionFeedback(key, customText) {
    const messages = {
      tutorial: "Tutorial mode! Let's learn together! 📘",
      pikmin: "Pikmin mode selected! Let's go! 🌱",
      kuchi: "PARTY MODE ACTIVATED! Let's celebrate! 🎉🎉",
      infinite: "Choose a buddy for Infinite Mode!"
    };

    const messageText = customText != null ? customText : messages[key];
    if (!messageText) {
      return;
    }

    // Create floating message
    const message = document.createElement('div');
    message.className = 'selection-message';
    message.textContent = messageText;
    message.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      padding: 20px 40px;
      border-radius: 20px;
      font-size: 1.5rem;
      z-index: 1000;
      box-shadow: 0 10px 30px rgba(0,0,0,0.3);
      animation: messagePop 1s ease;
      font-family: 'PastelCrayon', sans-serif;
    `;
    
    // Add extra effects for Kuchi mode
    if (key === 'kuchi') {
      message.style.background = 'linear-gradient(45deg, #fa709a, #fee140, #fa709a)';
      message.style.color = 'white';
      message.style.animation = 'messagePop 1s ease, partyBounce 0.5s ease infinite';
    } else if (key.startsWith('infinite')) {
      message.style.background = 'linear-gradient(135deg, #ede7ff, #f5efff)';
      message.style.color = '#3a2d73';
    }
    
    document.body.appendChild(message);
    
    setTimeout(() => {
      message.remove();
    }, 1500);
  },
  
  getInfinitePetLabel(petType) {
    if (!petType) {
      return null;
    }
    const key = String(petType).toLowerCase();
    if (Object.prototype.hasOwnProperty.call(INFINITE_PET_LABELS, key)) {
      return INFINITE_PET_LABELS[key];
    }
    return key.charAt(0).toUpperCase() + key.slice(1);
  },

  setActiveInfiniteOption(petType) {
    if (!Array.isArray(this.infiniteOptionButtons)) {
      return;
    }
    this.infiniteOptionButtons.forEach((button) => {
      if (!button) {
        return;
      }
      const isActive = button.dataset && button.dataset.pet === petType;
      button.classList.toggle('is-selected', Boolean(isActive));
      button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
    });
  },

  updateInfiniteModalState() {
    if (!this.infiniteModal) {
      return;
    }

    let overview = null;
    if (globalThis.StateStore && typeof globalThis.StateStore.getInfiniteOverview === 'function') {
      try {
        if (!globalThis.StateStore.isReady || globalThis.StateStore.isReady()) {
          overview = globalThis.StateStore.getInfiniteOverview();
        }
      } catch (error) {
        console.warn('DifficultyController: unable to read infinite overview', error);
      }
    }

    const streakValue = overview && typeof overview.streak === 'number' ? overview.streak : 0;
    if (this.infiniteStreakDisplay) {
      this.infiniteStreakDisplay.textContent = String(streakValue);
    }

    const appearanceKey = overview && overview.appearance ? String(overview.appearance) : null;
    if (this.infiniteAppearanceDisplay) {
      const label = this.getInfinitePetLabel(appearanceKey);
      const text = label ? 'Last buddy: ' + label : 'Last buddy: Not chosen yet';
      this.infiniteAppearanceDisplay.textContent = text;
    }

    this.setActiveInfiniteOption(appearanceKey);
  },

  openInfiniteModal() {
    if (!this.infiniteModal) {
      return;
    }

    this.updateInfiniteModalState();

    this.infiniteModal.classList.add('open');
    this.infiniteModal.setAttribute('aria-hidden', 'false');

    if (!this.infiniteKeyHandler) {
      this.infiniteKeyHandler = (event) => {
        if (event.key === 'Escape') {
          this.closeInfiniteModal();
        }
      };
    }

    document.addEventListener('keydown', this.infiniteKeyHandler);

    const activeSelection = this.infiniteModal.querySelector('.infinite-option.is-selected');
    const focusTarget = activeSelection || this.infiniteModal.querySelector('[data-pet]');
    if (focusTarget) {
      focusTarget.focus();
    }
  },

  closeInfiniteModal() {
    if (!this.infiniteModal) {
      return;
    }

    this.infiniteModal.classList.remove('open');
    this.infiniteModal.setAttribute('aria-hidden', 'true');

    if (this.infiniteKeyHandler) {
      document.removeEventListener('keydown', this.infiniteKeyHandler);
    }
  },

  startInfiniteRun(petType) {
    if (this.isTransitioning) {
      return;
    }

    if (!petType) {
      return;
    }

    this.setActiveInfiniteOption(petType);

    if (globalThis.StateStore && typeof globalThis.StateStore.setInfiniteAppearance === 'function') {
      try {
        if (!globalThis.StateStore.isReady || globalThis.StateStore.isReady()) {
          globalThis.StateStore.setInfiniteAppearance(petType);
        }
      } catch (error) {
        console.warn('DifficultyController: failed to persist infinite appearance', error);
      }
    }

    this.updateInfiniteModalState();
    this.closeInfiniteModal();
    this.isTransitioning = true;
    this.selectedDifficulty = 'infinite';
    AudioManager.playSound('select');

    const chosenName = this.getInfinitePetLabel(petType) || 'Your buddy';
    const message = chosenName + ' is ready for your infinite check-in!';
    this.showSelectionFeedback('infinite-start', message);

    if (window.ScreenTransition) {
      clearTimeout(this.transitionTimeout);
      this.transitionTimeout = setTimeout(() => {
        ScreenTransition.play({ direction: 'forward' });
        this.transitionTimeout = null;
      }, 1000);
    }

    AudioManager.fadeOutIntroAndPlayTransition(() => {
      setTimeout(() => {
        App.startGame('pikmin', { petTypeOverride: petType, mode: 'infinite' });

        if (globalThis.StateStore && typeof globalThis.StateStore.recordInteraction === 'function') {
          try {
            if (!globalThis.StateStore.isReady || globalThis.StateStore.isReady()) {
              globalThis.StateStore.recordInteraction({ forceSave: true });
            }
          } catch (error) {
            console.warn('DifficultyController: failed to record infinite interaction', error);
          }
        }

        setTimeout(() => {
          AudioManager.stopTransitionMusic();
        }, 1000);

        this.isTransitioning = false;
      }, 600);
    });
  },

  updateExtremeLock() {
    const kuchiCard = document.querySelector('.difficulty-card.kuchi');
    if (!kuchiCard) return;

    // Get current streak
    let streak = 0;
    if (globalThis.StateStore && typeof globalThis.StateStore.getInfiniteStreak === 'function') {
      try {
        streak = globalThis.StateStore.getInfiniteStreak();
        console.log('Extreme lock check - Current streak:', streak);
      } catch (error) {
        console.warn('DifficultyController: unable to read streak', error);
      }
    }

    // Lock if streak < 1
    if (streak < 1) {
      kuchiCard.classList.add('locked');

      // Add lock overlay if it doesn't exist
      if (!kuchiCard.querySelector('.lock-overlay')) {
        const lockOverlay = document.createElement('div');
        lockOverlay.className = 'lock-overlay';
        lockOverlay.innerHTML = `
          <div class="lock-icon">🔒</div>
          <div class="lock-text">Requires 1 Infinite Streak</div>
        `;
        kuchiCard.appendChild(lockOverlay);
      }
    } else {
      kuchiCard.classList.remove('locked');
      const lockOverlay = kuchiCard.querySelector('.lock-overlay');
      if (lockOverlay) {
        lockOverlay.remove();
      }
    }
  },

  updateInfiniteCooldownDisplay() {
    const cooldownDisplay = document.getElementById('infiniteCooldownDisplay');
    const cooldownTimer = document.getElementById('infiniteCooldownTimer');

    if (!cooldownDisplay || !cooldownTimer) {
      return;
    }

    // Get cooldown from StateStore
    let cooldownMs = 0;
    if (globalThis.StateStore && typeof globalThis.StateStore.getInfiniteOverview === 'function') {
      try {
        if (!globalThis.StateStore.isReady || globalThis.StateStore.isReady()) {
          const overview = globalThis.StateStore.getInfiniteOverview();
          const lastCheckInAt = overview && overview.lastCheckInAt ? Number(overview.lastCheckInAt) : 0;

          if (lastCheckInAt > 0) {
            const DAY_IN_MS = 24 * 60 * 60 * 1000;
            const elapsed = Date.now() - lastCheckInAt;
            if (elapsed < DAY_IN_MS) {
              cooldownMs = DAY_IN_MS - elapsed;
            }
          }
        }
      } catch (error) {
        console.warn('DifficultyController: unable to read cooldown', error);
      }
    }

    // Update display
    if (cooldownMs > 0) {
      const hours = Math.floor(cooldownMs / (60 * 60 * 1000));
      const minutes = Math.floor((cooldownMs % (60 * 60 * 1000)) / (60 * 1000));
      const seconds = Math.floor((cooldownMs % (60 * 1000)) / 1000);

      let timeStr = '';
      if (hours > 0) {
        timeStr = `${hours}h ${minutes}m`;
      } else if (minutes > 0) {
        timeStr = `${minutes}m ${seconds}s`;
      } else {
        timeStr = `${seconds}s`;
      }

      cooldownTimer.textContent = timeStr;
      cooldownDisplay.style.display = 'block';
    } else {
      cooldownDisplay.style.display = 'none';
    }
  },

  goBack() {
    AudioManager.playSound('button');

    // Clear cooldown interval
    if (this.cooldownInterval) {
      clearInterval(this.cooldownInterval);
      this.cooldownInterval = null;
    }

    if (window.ScreenTransition) {
      clearTimeout(this.transitionTimeout);
      this.transitionTimeout = null;
      ScreenTransition.play({ direction: 'reverse' });
    }

    AudioManager.restartIntroMusic();
    App.transitionToScreen('difficulty', 'menu');
  }
};


