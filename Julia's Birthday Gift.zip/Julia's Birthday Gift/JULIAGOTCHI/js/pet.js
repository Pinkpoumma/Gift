// js/pet.js - Advanced Pet Behavior and Animation System
const PetSystem = {
  currentPet: null,
  currentState: 'idle',
  currentAnimation: null,
  animationFrame: 0,
  animationTimer: null,
  stateTimer: null,
  poopTimer: null,
  position: { x: 150, y: 100 }, // Pixel based
  targetPosition: null,
  moveSpeed: 2.4,
  speechBubble: null,
  moodModifier: 1,
  lastAction: Date.now(),
  poops: [],
  walkingSound: null,
  walkCooldown: null,
  speechTimeout: null,
  speechAudio: null,
  isDragging: false,
  dragPointerId: null,
  dragOffset: { x: 0, y: 0 },
  dragStart: null,
  ignoreNextClick: false,
  petSpriteElement: null,
  petCharacterElement: null,
  boundPointerDown: null,
  boundPointerMove: null,
  boundPointerUp: null,
  boundSpriteClick: null,
  
  // Sprite configurations
  sprites: {
    kuchi: {
      idle: { width: 64, height: 64, frames: 1, speed: 500 }, // Fixed: 1 frame for idle
      talk: { width: 64, height: 64, frames: 2, speed: 200 },
      walk: { width: 64, height: 64, frames: 2, speed: 150 }
    },
    pikmin: {
      idle: { width: 64, height: 64, frames: 1, speed: 600 }, // Fixed: 1 frame for idle
      talk: { width: 64, height: 64, frames: 2, speed: 200 },
      walk: { width: 64, height: 64, frames: 4, speed: 150 }
    },
    chikawa: {
      idle: { width: 64, height: 64, frames: 1, speed: 900, sheet: 'assets/sprites/chikawa_idle.png' },
      talk: { width: 64, height: 64, frames: 1, speed: 900, sheet: 'assets/sprites/chikawa_idle.png' },
      walk: { width: 64, height: 64, frames: 1, speed: 900, sheet: 'assets/sprites/chikawa_idle.png' }
    },
    chikawa: {
      name: 'Chikawa',
      energy: 'reserved',
      phrases: {
        hungry: ['...'],
        sleepy: ['...'],
        bored: ['...'],
        happy: ['...'],
        sad: ['...'],
        random: ['...']
      }
    }
  },
  
  // Pet personalities and phrases
  personalities: {
    kuchi: {
      name: 'Kuchi',
      energy: 'chaotic',
      phrases: {
        hungry: [
          "IM SO HUNGRY I COULD EAT JULIA EHLER... 😐",
          "GUHHHH. FOOD. NOW.",
          "*dramatic sigh* I'm wasting away..."
        ],
        sleepy: [
          "AHHHHHHHHHHHHHHHHHHH! *flails*",
          "*yawns*",
          "HELLLLLP! HELLLLP ME!",
        ],
        bored: [
          "Brochacho, Can we do somthing please... ANYTHING? ",
          "I DEMAND YOU TO ENTERTAIN ME! 🎭",
          "Let's play something EXTREME! 🔥",
        ],
        happy: [
          "HIPPY DIPPY! 🌈",
          "YAYAYAYAYAY!",
          "I'm so Sigma!",
          "I sure hope I live a long fuffilling life!"
        ],
        sad: [
          "This is the WORST! 😭",
          "Everything is terrible and dramatic! 💔",
          "Gerp... :("
        ],
        random: [
          "Did you know I can juggle? 🤹‍♂️ if only i had thumbs 😔",
          "I had the weirdest dream about cheese! 🧀",
          "Vincent Adultman Is the worst character in media.",
          "Reality is an illusion! Buy gold! Wait, what?",
          "Can we watch somthing in Watch Party?"
        ]
      }
    },
    pikmin: {
      name: 'Pikmin',
      energy: 'gentle',
      phrases: {
        hungry: [
          "Could I have a snack perchance? 🍓",
          "Im a little peckish...",
          "Food would be nice... if you're not busy..."
        ],
        sleepy: [
          "Maybe just a little nap? 💤",
          "Counting sheep sounds nice... 🐑",
          "Is it bedtime yet? *rubs eyes*"
        ],
        bored: [
          "Want to play together? ⚾",
          "Maybe we could play catch? 🎾",
          "I'd love some Entertainment! 💙"
        ],
        happy: [
          "Yippee! 🎉",
          "Thank you for playing with me! 💚",
          "I'm so glad we're friends! 😊"
        ],
        sad: [
          "I don't feel so good...",
          "Could use a hug...",
          "Everything feels gloomy..."
        ],
        random: [
          "I found a pretty leaf today! 🍃",
          "My eyes are up here pal...",
          "I wonder what clouds taste like? ☁️",
          "Mmm burger 🍔",
          "I had a dream about giant Sunflowers! 🌻"
        ]
      }
    }
  },
  
  getStageElement() {
    return document.getElementById('petStage') || document.getElementById('petContainer');
  },

  getStageBounds() {
    const stage = this.getStageElement();
    if (!stage) {
      return { width: 400, height: 250 };
    }
    const width = stage.clientWidth || stage.offsetWidth || 400;
    const height = stage.clientHeight || stage.offsetHeight || 250;
    return { width, height };
  },

  clampPositionToStage(position = this.position) {
    const stage = this.getStageElement();
    if (!stage || !position) {
      return;
    }
    const { width, height } = this.getStageBounds();
    const spriteSize = 64;
    const horizontalPadding = 32;
    const topPadding = 24;
    const floorOffset = 80;

    const maxX = Math.max(horizontalPadding, width - spriteSize - horizontalPadding);
    const maxY = Math.max(topPadding, height - floorOffset - spriteSize);

    position.x = Math.min(Math.max(position.x, horizontalPadding), maxX);
    position.y = Math.min(Math.max(position.y, topPadding), maxY);
    this.position = position;
  },

  init(petType) {
    this.currentPet = petType;
    const { width, height } = this.getStageBounds();
    const defaultX = Math.max(40, (width / 2) - 32);
    const defaultY = Math.max(40, height - 120);
    this.position = { x: defaultX, y: defaultY };
    this.currentState = 'idle';
    this.animationFrame = 0;
    this.poops = [];
    this.updateMood();
    this.clampPositionToStage();
    this.render();
    this.startBehaviorLoop();
    if (this.currentPet !== 'chikawa') {
      this.walkAround();
    } else {
      this.startAnimation('idle');
    }
    this.startPoopTimer();
  },
  
  startPoopTimer() {
    // Clear existing timer
    if (this.poopTimer) {
      clearInterval(this.poopTimer);
    }
    
    // Set poop frequency based on pet type
    const poopInterval = this.currentPet === 'kuchi' 
      ? 15000 + Math.random() * 5000  // 15-20 seconds for Kuchi
      : this.currentPet === 'chikawa'
        ? 45000 + Math.random() * 15000  // Chikawa keeps it tidy
        : 30000;  // 30 seconds for Pikmin (twice per minute)
    
    this.poopTimer = setInterval(() => {
      this.createPoop();
    }, poopInterval);
  },
  
  createPoop() {
    const stage = this.getStageElement();
    if (!stage || GameController.currentMinigame) return; // Don't poop during minigames

    const poop = document.createElement('div');
    poop.className = 'poop';
    poop.style.position = 'absolute';
    poop.style.left = `${this.position.x + 20}px`;
    const stageHeight = this.getStageBounds().height;
    const floorLimit = Math.max(0, stageHeight - 70);
    const poopTop = Math.min(this.position.y + 30, floorLimit);
    poop.style.top = `${poopTop}px`;
    poop.style.fontSize = '20px';
    poop.style.zIndex = '6';
    poop.innerHTML = '💩';

    stage.appendChild(poop);
    this.poops.push(poop);

    // Update decay rate in GameController
    GameController.updatePoopPenalty(this.poops.length);
  },
  
  cleanPoops() {
    if (this.poops.length === 0) return;
    
    // Create water wave effect
    const stage = this.getStageElement();
    if (!stage) return;
    const wave = document.createElement('div');
    wave.className = 'cleaning-wave';
    wave.style.cssText = `
      position: absolute;
      left: 0;
      bottom: 0;
      width: 100%;
      height: 140%;
      background: linear-gradient(180deg, rgba(64, 164, 255, 0) 0%, rgba(64, 164, 255, 0.6) 40%, rgba(64, 164, 255, 0.85) 60%, rgba(64, 164, 255, 0) 100%);
      transform: translateY(100%);
      animation: waveCleanVertical 0.65s ease-out forwards;
      pointer-events: none;
      z-index: 50;
    `;
    
    stage.appendChild(wave);
    
    // Play cleaning sound
    const cleanSound = new Audio('assets/audio/button.mp3');
    cleanSound.volume = AudioManager.sfxVolume;
    cleanSound.play().catch(e => console.log('Could not play clean sound'));
    
    // Fade out poops
    this.poops.forEach((poop, index) => {
      setTimeout(() => {
        poop.style.transition = 'opacity 0.5s ease-out';
        poop.style.opacity = '0';
        setTimeout(() => poop.remove(), 500);
      }, index * 50); // Stagger the fade
    });
    
    // Clear poop array and reset penalty
    setTimeout(() => {
      this.poops = [];
      GameController.updatePoopPenalty(0);
      if (typeof document !== 'undefined') {
        document.dispatchEvent(new CustomEvent('tutorial:cleanComplete', { detail: { remaining: 0 } }));
      }
    }, 600);
    
    // Remove wave
    setTimeout(() => wave.remove(), 700);

    if (this.currentPet === 'chikawa') {
      this.groan();
      return;
    }

    // Positive reinforcement
    this.startAnimation('talk');
    this.showSpeechBubble(this.currentPet === 'kuchi'
      ? "Clean up crew, assemble! 🚿"
      : "All clean! Thank you! 🧹");

    setTimeout(() => {
      this.hideSpeechBubble(true);
      this.startAnimation('idle');
    }, 2500);
  },

  render() {
    const stage = this.getStageElement();
    if (!stage) {
      console.log('Pet stage not found');
      return;
    }

    this.clampPositionToStage();

    // Clear any existing pet sprite
    let existingSprite = document.getElementById('petSprite');
    if (existingSprite) {
      existingSprite.remove();
    }

    // Create pet sprite container
    const petSprite = document.createElement('div');
    petSprite.id = 'petSprite';
    petSprite.className = 'pet-sprite';
    petSprite.style.position = 'absolute';
    petSprite.style.left = `${this.position.x}px`;
    petSprite.style.top = `${this.position.y}px`;

    // Create pet character div
    const petElement = document.createElement('div');
    petElement.id = 'petCharacter';
    petElement.className = 'pet-character';
    petElement.classList.add('pet-' + this.currentPet);
    petElement.style.width = '64px';
    petElement.style.height = '64px';

    petSprite.appendChild(petElement);
    stage.appendChild(petSprite);

    this.setupInteractionHandlers(petSprite, petElement);

    // Start with idle animation
    this.startAnimation('idle');
  },

  setupInteractionHandlers(petSprite, petElement) {
    if (typeof window === 'undefined' || !petSprite) {
      return;
    }

    petSprite.style.touchAction = 'none';
    petSprite.style.cursor = 'grab';

    this.petSpriteElement = petSprite;
    this.petCharacterElement = petElement;

    if (!this.boundPointerDown) {
      this.boundPointerDown = this.handlePointerDown.bind(this);
      this.boundPointerMove = this.handlePointerMove.bind(this);
      this.boundPointerUp = this.handlePointerUp.bind(this);
      this.boundSpriteClick = this.handleSpriteClick.bind(this);
    }

    petSprite.removeEventListener('pointerdown', this.boundPointerDown);
    petSprite.removeEventListener('pointerup', this.boundPointerUp);
    petSprite.removeEventListener('pointercancel', this.boundPointerUp);
    petSprite.removeEventListener('click', this.boundSpriteClick);

    petSprite.addEventListener('pointerdown', this.boundPointerDown);
    petSprite.addEventListener('pointerup', this.boundPointerUp);
    petSprite.addEventListener('pointercancel', this.boundPointerUp);
    petSprite.addEventListener('click', this.boundSpriteClick);
  },

  handlePointerDown(event) {
    if (event.button !== undefined && event.button !== 0) {
      return;
    }

    const stage = this.getStageElement();
    if (!stage || GameController.currentMinigame) {
      return;
    }

    event.preventDefault();

    this.isDragging = true;
    this.dragPointerId = event.pointerId;
    this.dragStart = { x: this.position.x, y: this.position.y };
    this.ignoreNextClick = false;

    const rect = stage.getBoundingClientRect();
    this.dragOffset = {
      x: event.clientX - rect.left - this.position.x,
      y: event.clientY - rect.top - this.position.y
    };

    this.targetPosition = null;

    if (this.walkCooldown) {
      clearTimeout(this.walkCooldown);
      this.walkCooldown = null;
    }

    if (this.walkingSound) {
      try { this.walkingSound.pause(); } catch (_) {}
      this.walkingSound = null;
    }

    const sprite = this.petSpriteElement;
    if (sprite) {
      sprite.classList.add('pet-dragging');
      sprite.style.zIndex = '40';
      sprite.setPointerCapture(event.pointerId);
      sprite.addEventListener('pointermove', this.boundPointerMove);
    }

    this.startAnimation('idle');
  },

  handlePointerMove(event) {
    if (!this.isDragging || event.pointerId !== this.dragPointerId) {
      return;
    }

    const stage = this.getStageElement();
    if (!stage) {
      return;
    }

    const rect = stage.getBoundingClientRect();
    const nextX = event.clientX - rect.left - this.dragOffset.x;
    const nextY = event.clientY - rect.top - this.dragOffset.y;

    const prevX = this.position.x;
    const prevY = this.position.y;

    this.position.x = nextX;
    this.position.y = nextY;
    this.clampPositionToStage();
    this.updateSpritePosition();

    if (!this.ignoreNextClick) {
      const moved = Math.hypot(this.position.x - this.dragStart.x, this.position.y - this.dragStart.y);
      if (moved > 4) {
        this.ignoreNextClick = true;
      }
    }

    const petCharacter = this.petCharacterElement || document.getElementById('petCharacter');
    if (petCharacter && Math.abs(this.position.x - prevX) > 1) {
      petCharacter.style.transform = this.position.x < prevX ? 'scaleX(-1)' : 'scaleX(1)';
    }
  },

  handlePointerUp(event) {
    if (this.dragPointerId !== null && event.pointerId !== this.dragPointerId) {
      return;
    }

    const sprite = this.petSpriteElement;
    if (sprite) {
      sprite.classList.remove('pet-dragging');
      sprite.style.zIndex = '';
      sprite.removeEventListener('pointermove', this.boundPointerMove);
      try {
        sprite.releasePointerCapture(event.pointerId);
      } catch (_) {}
    }

    this.isDragging = false;
    this.dragPointerId = null;
    this.dragOffset = { x: 0, y: 0 };

    this.clampPositionToStage();
    this.updateSpritePosition();

    if (this.currentPet !== 'chikawa') {
      if (this.walkCooldown) {
        clearTimeout(this.walkCooldown);
      }
      this.walkCooldown = setTimeout(() => {
        this.walkCooldown = null;
        if (!this.isDragging && !this.targetPosition && !GameController.currentMinigame) {
          this.walkAround();
        }
      }, 1600);
    }
  },

  handleSpriteClick(event) {
    if (this.ignoreNextClick) {
      this.ignoreNextClick = false;
      return;
    }

    if (GameController.currentMinigame) {
      return;
    }

    this.speak();
  },

  updateSpritePosition() {
    const sprite = this.petSpriteElement || document.getElementById('petSprite');
    if (sprite) {
      sprite.style.left = `${this.position.x}px`;
      sprite.style.top = `${this.position.y}px`;
    }
  },

  updateSprite() {
    const petElement = document.getElementById('petCharacter');
    if (!petElement) return;
    
    const typeConfig = this.sprites[this.currentPet] || this.sprites.pikmin;
    const config = typeConfig[this.currentState] || typeConfig.idle || (this.sprites.pikmin ? this.sprites.pikmin.idle : null);

    if (!config) {
      console.warn(`Missing sprite config for ${this.currentPet} state ${this.currentState}`);
      return;
    }

    const spriteSheet = config.sheet || `assets/sprites/${this.currentPet}_${this.currentState}.png`;
    
    // Set the sprite sheet as background
    petElement.style.backgroundImage = `url('${spriteSheet}')`;
    petElement.style.width = `${config.width}px`;
    petElement.style.height = `${config.height}px`;
    petElement.style.backgroundSize = `${config.width * config.frames}px ${config.height}px`;
    petElement.style.backgroundPosition = `-${this.animationFrame * config.width}px 0px`;
    petElement.style.imageRendering = 'pixelated';
    petElement.style.backgroundRepeat = 'no-repeat';
  },
  
  startAnimation(state) {
    // Clear existing animation
    if (this.animationTimer) {
      clearInterval(this.animationTimer);
      this.animationTimer = null;
    }
    
    this.currentState = state;
    this.animationFrame = 0;
    
    const typeConfig = this.sprites[this.currentPet] || this.sprites.pikmin;
    const config = typeConfig[state] || typeConfig.idle || (this.sprites.pikmin ? this.sprites.pikmin.idle : null);
    
    if (!config) {
      console.warn(`Missing animation config for ${this.currentPet} -> ${state}`);
      return;
    }
    
    if (config.frames > 1) {
      this.animationTimer = setInterval(() => {
        this.animationFrame = (this.animationFrame + 1) % config.frames;
        this.updateSprite();
      }, config.speed);
    }
    
    this.updateSprite();
  },
  
  updateMood() {
    const stats = GameController.pet;
    if (!stats) return;
    
    const avgMood = (stats.hunger + stats.sleep + stats.happiness) / 3;
    
    // Update mood modifier for behavior frequency
    if (avgMood > 80) {
      this.moodModifier = 1.5; // Very active when happy
    } else if (avgMood > 60) {
      this.moodModifier = 1.2;
    } else if (avgMood > 40) {
      this.moodModifier = 1.0;
    } else if (avgMood > 20) {
      this.moodModifier = 0.8;
    } else {
      this.moodModifier = 0.5; // Lethargic when stats are low
    }
  },
  
  startBehaviorLoop() {
    // Clear existing timer
    if (this.stateTimer) {
      clearTimeout(this.stateTimer);
    }
    
    if (this.currentPet === 'chikawa') {
      const performGroan = () => {
        this.updateMood();

        if (GameController.currentMinigame) {
          this.stateTimer = setTimeout(performGroan, 4000);
          return;
        }

        if (Math.random() < 0.5) {
          this.groan();
        } else {
          this.startAnimation('idle');
        }

        const nextTime = 5000 + Math.random() * 3500;
        this.stateTimer = setTimeout(performGroan, nextTime);
      };

      performGroan();
      return;
    }
    
    // Random behavior every 5-15 seconds (modified by mood)
    const performBehavior = () => {
      this.updateMood();
      
      // Don't do behaviors during minigames
      if (GameController.currentMinigame) {
        return;
      }
      
      const behaviors = ['idle', 'talk', 'walk', 'interact'];
      const weights = this.getBehaviorWeights();
      const behavior = this.weightedRandom(behaviors, weights);
      
      this.performBehavior(behavior);
      
      // Schedule next behavior
      const nextTime = (2200 + Math.random() * 3800) / this.moodModifier; // Shorter intervals
      this.stateTimer = setTimeout(performBehavior, nextTime);
    };
    
    // Start the loop
    performBehavior();
  },
  
  getBehaviorWeights() {
    const stats = GameController.pet;
    if (!stats) return [30, 30, 30, 10];
    
    // Kuchi should move much more often
    if (this.currentPet === 'chikawa') {
      return [100, 0, 0, 0];
    }

    const baseWeights = this.currentPet === 'kuchi' 
      ? [15, 18, 55, 12]  // Kuchi: Much more walking
      : [22, 22, 44, 12]; // Pikmin: Increased roaming
    
    const weights = [...baseWeights];
    
    // Adjust weights based on stats
    if (stats.hunger < 30) {
      weights[1] += 20;
      weights[3] += 10;
    }
    
    if (stats.sleep < 30) {
      weights[0] += 15;
      weights[2] -= 5;
    }
    
    if (stats.happiness < 30) {
      weights[1] += 15;
      weights[3] += 15;
    }
    
    if (stats.happiness > 70) {
      weights[2] += 25;
    }
    
    return weights;
  },
  
  weightedRandom(items, weights) {
    const totalWeight = weights.reduce((a, b) => a + b, 0);
    let random = Math.random() * totalWeight;
    
    for (let i = 0; i < items.length; i++) {
      random -= weights[i];
      if (random <= 0) {
        return items[i];
      }
    }
    
    return items[0];
  },
  
  performBehavior(behavior) {
    switch(behavior) {
      case 'idle':
        this.startAnimation('idle');
        break;
        
      case 'talk':
        if (this.currentPet === 'chikawa') {
          this.groan();
        } else {
          this.speak();
        }
        break;
        
      case 'walk':
        if (this.currentPet !== 'chikawa') {
          this.walkAround();
        }
        break;
        
      case 'interact':
        this.interactWithUser();
        break;
    }
  },
  
  walkAround() {
    if (this.currentPet === 'chikawa') {
      return;
    }

    if (this.isDragging) {
      if (!this.walkCooldown) {
        this.walkCooldown = setTimeout(() => {
          this.walkCooldown = null;
          if (!this.isDragging && !this.targetPosition && !GameController.currentMinigame) {
            this.walkAround();
          }
        }, 1200);
      }
      return;
    }

    const stage = this.getStageElement();
    if (!stage) {
      return;
    }

    if (this.targetPosition && this.currentState === 'walk') {
      return;
    }

    const { width, height } = this.getStageBounds();
    const spriteSize = 64;
    const padX = 36;
    const padY = 30;
    const floorOffset = 90;

    const maxX = Math.max(padX, width - spriteSize - padX);
    const maxY = Math.max(padY, height - floorOffset - spriteSize);
    const rangeX = Math.max(12, maxX - padX);
    const rangeY = Math.max(12, maxY - padY);

    this.targetPosition = {
      x: padX + Math.random() * rangeX,
      y: padY + Math.random() * rangeY
    };

    this.startAnimation('walk');
    this.playWalkingSound();

    if (this.walkCooldown) {
      clearTimeout(this.walkCooldown);
    }

    this.walkCooldown = setTimeout(() => {
      if (!this.targetPosition && !GameController.currentMinigame) {
        this.walkAround();
      }
    }, Math.max(4000, 9000 / this.moodModifier));

    this.lastAction = Date.now();
    requestAnimationFrame(() => this.moveToTarget());
  },
  playWalkingSound() {
    if (this.currentPet === 'chikawa') {
      return;
    }

    if (this.walkingSound) {
      return;
    }

    try {
      const sound = new Audio('assets/audio/walking.mp3');
      sound.volume = AudioManager.sfxVolume * 0.35;
      sound.loop = true;
      sound.play().catch(() => {});
      this.walkingSound = sound;
    } catch (err) {
      console.warn('Unable to start walking sound', err);
    }
  },

  pulseAttention(selector) {
    if (!selector) {
      return;
    }

    const button = document.querySelector(selector);
    if (button) {
      button.classList.add('pulse-attention');
      setTimeout(() => button.classList.remove('pulse-attention'), 2600);
    }
  },

  cancelSpeech({ immediate = false, toIdle = true, hideBubble = true } = {}) {
    if (this.speechTimeout) {
      clearTimeout(this.speechTimeout);
      this.speechTimeout = null;
    }

    if (this.speechAudio) {
      try {
        this.speechAudio.pause();
        this.speechAudio.currentTime = 0;
      } catch (err) {
        console.warn('Could not stop speech audio', err);
      }
      this.speechAudio = null;
    }

    if (hideBubble) {
      this.hideSpeechBubble(immediate);
    }

    if (toIdle) {
      this.startAnimation('idle');
    }
  },

  groan(options = {}) {
    const targets = Array.isArray(options.highlight)
      ? options.highlight
      : options.highlight
        ? [options.highlight]
        : [];

    targets.forEach(selector => this.pulseAttention(selector));

    this.cancelSpeech({ immediate: true, toIdle: false });

    this.startAnimation('idle');

    const petElement = document.getElementById('petCharacter');
    if (petElement) {
      petElement.classList.remove('chikawa-groan');
      void petElement.offsetWidth;
      petElement.classList.add('chikawa-groan');
      setTimeout(() => petElement.classList.remove('chikawa-groan'), 700);
    }

    try {
      const groanSound = new Audio('assets/audio/talking.mp3');
      groanSound.volume = AudioManager.sfxVolume * 0.35;
      groanSound.playbackRate = 0.7;
      groanSound.currentTime = 0;
      groanSound.play().catch(() => {});

      this.speechAudio = groanSound;
      if (this.speechTimeout) {
        clearTimeout(this.speechTimeout);
      }
      this.speechTimeout = setTimeout(() => {
        if (this.speechAudio === groanSound) {
          try { groanSound.pause(); } catch (_) {}
          this.speechAudio = null;
          this.speechTimeout = null;
        }
      }, 1200);
    } catch (err) {
      console.warn('Could not play groan sound', err);
    }
  },

  speak() {
    if (this.currentPet === 'chikawa') {
      this.groan();
      return;
    }

    const stats = GameController.pet;
    const personality = this.personalities[this.currentPet];

    // Choose phrase category based on stats
    let category = 'random';

    if (stats.hunger < 30) {
      category = 'hungry';
    } else if (stats.sleep < 30) {
      category = 'sleepy';
    } else if (stats.happiness < 30) {
      category = 'sad';
    } else if (stats.happiness > 70) {
      category = 'happy';
    } else if (Math.random() < 0.3) {
      category = 'bored';
    }

    const phrases = personality.phrases[category];
    const phrase = phrases[Math.floor(Math.random() * phrases.length)];

    this.cancelSpeech({ immediate: true, toIdle: false });

    this.startAnimation('talk');
    this.showSpeechBubble(phrase);

    // Play talking sound
    const talkSound = new Audio('assets/audio/talking.mp3');
    talkSound.volume = AudioManager.sfxVolume * 0.5;
    talkSound.play().catch(e => console.log('Could not play talking sound', e));

    this.speechAudio = talkSound;
    if (this.speechTimeout) {
      clearTimeout(this.speechTimeout);
    }

    const talkDuration = 3000 + phrase.length * 50;
    this.speechTimeout = setTimeout(() => {
      if (this.speechAudio === talkSound) {
        this.cancelSpeech({ immediate: false, toIdle: true });
      }
    }, talkDuration);
  },


  showSpeechBubble(text) {
    // Remove existing bubble/audio
    this.cancelSpeech({ immediate: true, toIdle: false });
    
    const bubble = document.createElement('div');
    bubble.className = 'speech-bubble';
    bubble.id = 'speechBubble';
    bubble.textContent = text;

    // Add personality-specific styling
    bubble.classList.add(this.currentPet === 'kuchi' ? 'kuchi-speech' : 'pikmin-speech');

    const bubbleHost = document.getElementById('petDialogue');
    if (bubbleHost) {
      bubble.classList.add('anchored');
      bubbleHost.innerHTML = '';
      bubbleHost.appendChild(bubble);
    } else {
      const petSprite = document.getElementById('petSprite');
      const stage = this.getStageElement();
      if (petSprite && stage) {
        const petLeft = this.position.x;
        const stageWidth = stage.clientWidth;
        const bubbleWidth = 200; // Max width of bubble

        if (petLeft < bubbleWidth / 2) {
          bubble.style.left = '32px';
          bubble.style.transform = 'translateX(0) scale(0)';
        } else if (petLeft > stageWidth - bubbleWidth / 2) {
          bubble.style.left = 'auto';
          bubble.style.right = '32px';
          bubble.style.transform = 'translateX(0) scale(0)';
        }

        petSprite.appendChild(bubble);
      }
    }

    // Animate in
    setTimeout(() => {
      bubble.classList.add('show');
    }, 10);
  },
  
  hideSpeechBubble(immediate = false) {
    const bubble = document.getElementById('speechBubble');
    if (!bubble) {
      return;
    }

    bubble.classList.remove('show');
    const host = bubble.parentElement;
    const removeBubble = () => {
      bubble.remove();
      if (host && host.id === 'petDialogue') {
        host.innerHTML = '';
      }
    };

    if (immediate) {
      removeBubble();
    } else {
      setTimeout(removeBubble, 200);
    }
  },
  
  moveToTarget() {
    if (!this.targetPosition || this.isDragging) return;
    
    const dx = this.targetPosition.x - this.position.x;
    const dy = this.targetPosition.y - this.position.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance < 2) {
      // Reached target
      this.targetPosition = null;
      this.startAnimation('idle');
      // Stop walking sound
      if (this.walkingSound) {
        this.walkingSound.pause();
        this.walkingSound = null;
      }
      return;
    }
    
    // Move towards target
    const moveX = (dx / distance) * this.moveSpeed;
    const moveY = (dy / distance) * this.moveSpeed;
    
    this.position.x += moveX;
    this.position.y += moveY;
    this.clampPositionToStage();

    // Update position
    const petSprite = document.getElementById('petSprite');
    if (petSprite) {
      petSprite.style.left = `${this.position.x}px`;
      petSprite.style.top = `${this.position.y}px`;
      
      // Flip horizontally if moving left
      const petCharacter = document.getElementById('petCharacter');
      if (petCharacter) {
        petCharacter.style.transform = dx < 0 ? 'scaleX(-1)' : 'scaleX(1)';
      }
    }
    
    // Continue moving
    requestAnimationFrame(() => this.moveToTarget());
  },
  
  interactWithUser() {
    const stats = GameController.pet;
    const personality = this.personalities[this.currentPet];

    if (this.currentPet === 'chikawa') {
      if (stats.hunger < 40) {
        this.groan({ highlight: '.feed-btn' });
      } else if (stats.sleep < 40) {
        this.groan({ highlight: '.sleep-btn' });
      } else if (stats.happiness < 40) {
        this.groan({ highlight: '.play-btn' });
      } else {
        this.groan();
      }
      return;
    }
    
    // Choose interaction based on needs
    if (stats.hunger < 40) {
      this.requestFood();
    } else if (stats.sleep < 40) {
      this.requestSleep();
    } else if (stats.happiness < 40) {
      this.requestPlay();
    } else {
      // Random friendly interaction
      this.speak();
    }
  },
  
  requestFood() {
    if (this.currentPet === 'chikawa') {
      this.groan({ highlight: '.feed-btn' });
      return;
    }

    this.startAnimation('talk');
    const phrases = this.currentPet === 'kuchi' 
      ? ["FEED ME NOW! I DEMAND SUSTENANCE! 🍔", "I'M STARVING! THIS IS AN EMERGENCY! 🚨"]
      : ["I'm getting hungry... 🥺", "Could we get some food please? 🍓"];
    
    const phrase = phrases[Math.floor(Math.random() * phrases.length)];
    this.showSpeechBubble(phrase);
    
    // Pulse the feed button
    const feedBtn = document.querySelector('.feed-btn');
    if (feedBtn) {
      feedBtn.classList.add('pulse-attention');
      setTimeout(() => feedBtn.classList.remove('pulse-attention'), 3000);
    }
    
    setTimeout(() => {
      this.hideSpeechBubble();
      this.startAnimation('idle');
    }, 3000);
  },
  
  requestSleep() {
    if (this.currentPet === 'chikawa') {
      this.groan({ highlight: '.sleep-btn' });
      return;
    }

    this.startAnimation('talk');
    const phrases = this.currentPet === 'kuchi'
      ? ["I'M NOT TIRED! *falls over* 😴", "Sleep is for... *yawn* ...the weak... 💤"]
      : ["I'm sleepy... 😴", "Bedtime? Please? 💤"];
    
    const phrase = phrases[Math.floor(Math.random() * phrases.length)];
    this.showSpeechBubble(phrase);
    
    // Pulse the sleep button
    const sleepBtn = document.querySelector('.sleep-btn');
    if (sleepBtn) {
      sleepBtn.classList.add('pulse-attention');
      setTimeout(() => sleepBtn.classList.remove('pulse-attention'), 3000);
    }
    
    setTimeout(() => {
      this.hideSpeechBubble();
      this.startAnimation('idle');
    }, 3000);
  },
  
  requestPlay() {
    if (this.currentPet === 'chikawa') {
      this.groan({ highlight: '.play-btn' });
      return;
    }

    this.startAnimation('talk');
    const phrases = this.currentPet === 'kuchi'
      ? ["LET'S PLAY SOMETHING EXTREME! 🎮", "I'M BORED! ENTERTAIN ME! 🎪"]
      : ["Want to play? 🎮", "I'd love to play a game! ⚾"];
    
    const phrase = phrases[Math.floor(Math.random() * phrases.length)];
    this.showSpeechBubble(phrase);
    
    // Pulse the play button
    const playBtn = document.querySelector('.play-btn');
    if (playBtn) {
      playBtn.classList.add('pulse-attention');
      setTimeout(() => playBtn.classList.remove('pulse-attention'), 3000);
    }
    
    setTimeout(() => {
      this.hideSpeechBubble();
      this.startAnimation('idle');
    }, 3000);
  },
  
  // Special reactions
  reactToStatChange(stat, change) {
    if (this.currentPet === 'chikawa') {
      if (change < 0) {
        this.groan();
      }
      return;
    }

    // Quick reaction when stats change significantly
    if (Math.abs(change) > 10) {
      const isPositive = change > 0;
      let reaction = '';
      
      if (stat === 'hunger' && isPositive) {
        reaction = this.currentPet === 'kuchi' ? "YUM! MORE! 🍔" : "Thank you! 😊";
      } else if (stat === 'sleep' && isPositive) {
        reaction = this.currentPet === 'kuchi' ? "I feel... POWERFUL! 💪" : "Much better! 💤";
      } else if (stat === 'happiness' && isPositive) {
        reaction = this.currentPet === 'kuchi' ? "WHEEE! 🎉" : "So fun! 💚";
      } else if (!isPositive) {
        reaction = this.currentPet === 'kuchi' ? "THIS IS UNACCEPTABLE! 😤" : "Oh no... 😢";
      }
      
      if (reaction) {
        this.startAnimation('talk');
        this.showSpeechBubble(reaction);
        setTimeout(() => {
          this.hideSpeechBubble();
          this.startAnimation('idle');
        }, 2000);
      }
    }
  },
  
  pause() {
    // Store timers but don't clear them completely
    this.isPaused = true;
    if (this.animationTimer) {
      clearInterval(this.animationTimer);
      this.animationTimer = null;
    }
    if (this.walkingSound) {
      this.walkingSound.pause();
    }
  },

  resume() {
    this.isPaused = false;
    // Restart animation if pet exists
    if (this.currentPet && this.currentState) {
      this.playAnimation(this.currentState);
    }
  },

  cleanup() {
    if (this.animationTimer) clearInterval(this.animationTimer);
    if (this.stateTimer) clearTimeout(this.stateTimer);
    if (this.poopTimer) clearInterval(this.poopTimer);
    if (this.walkCooldown) {
      clearTimeout(this.walkCooldown);
      this.walkCooldown = null;
    }
    if (this.walkingSound) {
      this.walkingSound.pause();
      this.walkingSound = null;
    }

    if (this.petSpriteElement && this.boundPointerDown) {
      this.petSpriteElement.removeEventListener('pointerdown', this.boundPointerDown);
      this.petSpriteElement.removeEventListener('pointerup', this.boundPointerUp);
      this.petSpriteElement.removeEventListener('pointercancel', this.boundPointerUp);
      this.petSpriteElement.removeEventListener('pointermove', this.boundPointerMove);
      this.petSpriteElement.removeEventListener('click', this.boundSpriteClick);
      this.petSpriteElement.classList.remove('pet-dragging');
      if (typeof this.petSpriteElement.releasePointerCapture === 'function' && this.dragPointerId !== null) {
        try {
          this.petSpriteElement.releasePointerCapture(this.dragPointerId);
        } catch (_) {}
      }
    }

    this.petSpriteElement = null;
    this.petCharacterElement = null;
    this.isDragging = false;
    this.dragPointerId = null;
    this.dragOffset = { x: 0, y: 0 };
    this.ignoreNextClick = false;

    this.hideSpeechBubble();
    // Clean up any remaining poops
    this.poops.forEach(poop => poop.remove());
    this.poops = [];
  }
};

