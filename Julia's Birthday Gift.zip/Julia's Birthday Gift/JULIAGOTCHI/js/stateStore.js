﻿(function (global) {
  const STORAGE_KEY = 'tamogachiPlayerState';
  const HOUR_IN_MS = 60 * 60 * 1000;
  const DAY_IN_MS = 24 * 60 * 60 * 1000;
  const MIN_SAVE_INTERVAL_MS = 5000;

  const defaultState = {
    infinite: {
      appearance: null,
      streak: 0,
      lastCheckInAt: null,
      lastCheckInDay: null,
      lastInteraction: null,
      previousInteraction: null,
      stats: {
        hunger: 50,
        sleep: 50,
        happiness: 50
      }
    }
  };

  let state = null;
  let initPromise = null;
  let lastPersistTime = 0;
  let readyResolver;
  const readyPromise = new Promise((resolve) => {
    readyResolver = resolve;
  });

  const clone = (value) => JSON.parse(JSON.stringify(value));

  const clampStat = (value) => {
    const numberValue = Number(value);
    if (!Number.isFinite(numberValue)) {
      return 0;
    }
    return Math.max(0, Math.min(100, Math.round(numberValue * 10) / 10));
  };

  const padTwo = (value) => String(value).padStart(2, '0');

  const toDayKey = (timestamp) => {
    if (!Number.isFinite(timestamp) || timestamp <= 0) {
      return null;
    }
    const date = new Date(timestamp);
    return `${date.getUTCFullYear()}-${padTwo(date.getUTCMonth() + 1)}-${padTwo(date.getUTCDate())}`;
  };

  const mergeState = (source) => {
    const target = clone(defaultState);
    if (source && typeof source === 'object' && source.infinite && typeof source.infinite === 'object') {
      const srcInfinite = source.infinite;
      const destInfinite = target.infinite;
      const copyKeys = ['appearance', 'streak', 'lastCheckInAt', 'lastCheckInDay', 'lastInteraction', 'previousInteraction'];
      copyKeys.forEach((key) => {
        if (key in srcInfinite) {
          destInfinite[key] = srcInfinite[key];
        }
      });
      if (srcInfinite.stats && typeof srcInfinite.stats === 'object') {
        ['hunger', 'sleep', 'happiness'].forEach((key) => {
          if (key in srcInfinite.stats) {
            destInfinite.stats[key] = srcInfinite.stats[key];
          }
        });
      }
    }
    const destStats = target.infinite.stats;
    destStats.hunger = clampStat(destStats.hunger);
    destStats.sleep = clampStat(destStats.sleep);
    destStats.happiness = clampStat(destStats.happiness);
    const streakNumber = Number(target.infinite.streak);
    target.infinite.streak = Number.isFinite(streakNumber) && streakNumber > 0 ? Math.floor(streakNumber) : 0;
    return target;
  };

  const loadFromLocalStorage = () => {
    try {
      if (!global.localStorage) {
        return null;
      }
      const raw = global.localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        return null;
      }
      return JSON.parse(raw);
    } catch (error) {
      console.warn('StateStore: unable to read localStorage', error);
      return null;
    }
  };

  const persist = () => {
    if (!state) {
      return;
    }
    try {
      if (global.localStorage) {
        global.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
        lastPersistTime = Date.now();
      }
    } catch (error) {
      console.warn('StateStore: unable to persist state', error);
    }
  };

  const scheduleSave = (force) => {
    if (!state) {
      return;
    }
    const now = Date.now();
    if (force || now - lastPersistTime >= MIN_SAVE_INTERVAL_MS) {
      persist();
    }
  };

  const updateInteractionTimestamp = () => {
    if (state) {
      state.infinite.lastInteraction = Date.now();
    }
  };

  const applyOfflineDecay = (target) => {
    const lastInteraction = Number(target.infinite.lastInteraction);
    if (!Number.isFinite(lastInteraction) || lastInteraction <= 0) {
      target.infinite.lastInteraction = Date.now();
      target.infinite.previousInteraction = null;
      return;
    }
    const now = Date.now();
    const elapsedMs = now - lastInteraction;
    if (elapsedMs < HOUR_IN_MS) {
      return;
    }
    const hoursAway = Math.floor(elapsedMs / HOUR_IN_MS);
    if (hoursAway <= 0) {
      return;
    }
    const decay = hoursAway * 3;
    target.infinite.previousInteraction = lastInteraction;
    ['hunger', 'sleep', 'happiness'].forEach((key) => {
      target.infinite.stats[key] = clampStat(target.infinite.stats[key] - decay);
    });
  };

  const ensureReady = () => {
    if (!state) {
      throw new Error('StateStore: init() has not completed');
    }
  };

  const getStatsSnapshot = (source) => {
    const data = source || state.infinite.stats;
    return {
      hunger: clampStat(data.hunger),
      sleep: clampStat(data.sleep),
      happiness: clampStat(data.happiness)
    };
  };

  const finalise = (payload) => {
    if (!state) {
      state = mergeState(payload);
      applyOfflineDecay(state);
      updateInteractionTimestamp();
      scheduleSave(true);
      if (typeof readyResolver === 'function') {
        readyResolver(state);
      }
    }
    return state;
  };

  const api = {
    ready: readyPromise,
    init() {
      if (state) {
        return Promise.resolve(state);
      }
      if (initPromise) {
        return initPromise;
      }
      const fromStorage = loadFromLocalStorage();
      if (fromStorage) {
        finalise(fromStorage);
        initPromise = Promise.resolve(state);
        return initPromise;
      }
      const handleFailure = (error) => {
        if (error) {
          console.warn('StateStore: falling back to default state', error);
        }
        return finalise(clone(defaultState));
      };
      initPromise = fetch('data/player-state.json')
        .then((response) => {
          if (!response.ok) {
            throw new Error(`Failed to load player-state.json: ${response.status}`);
          }
          return response.json();
        })
        .then((data) => finalise(data))
        .catch(handleFailure);
      return initPromise;
    },
    isReady() {
      return Boolean(state);
    },
    getInfiniteAppearance() {
      ensureReady();
      return state.infinite.appearance || null;
    },
    setInfiniteAppearance(petType) {
      ensureReady();
      state.infinite.appearance = petType || null;
      updateInteractionTimestamp();
      scheduleSave(true);
    },
    getInfiniteStats() {
      ensureReady();
      return getStatsSnapshot();
    },

    getInfiniteStreak() {
      ensureReady();
      const streakNumber = Number(state.infinite.streak);
      return Number.isFinite(streakNumber) && streakNumber > 0 ? Math.floor(streakNumber) : 0;
    },
    updateStats(stats, options = {}) {
      ensureReady();
      if (!stats || typeof stats !== 'object') {
        return getStatsSnapshot();
      }
      const dest = state.infinite.stats;
      ['hunger', 'sleep', 'happiness'].forEach((key) => {
        if (key in stats) {
          dest[key] = clampStat(stats[key]);
        }
      });
      if (options.recordInteraction !== false) {
        updateInteractionTimestamp();
      }
      scheduleSave(Boolean(options.force));
      return getStatsSnapshot(dest);
    },
    recordInteraction(options = {}) {
      ensureReady();
      updateInteractionTimestamp();
      if (options.forceSave) {
        scheduleSave(true);
      }
    },
    evaluateStreak(stats) {
      ensureReady();
      const sample = getStatsSnapshot(stats);
      const allHigh = ['hunger', 'sleep', 'happiness'].every((key) => sample[key] >= 70);
      const now = Date.now();
      const lastAward = Number(state.infinite.lastCheckInAt);
      let cooldownMs = 0;
      if (Number.isFinite(lastAward) && lastAward > 0) {
        const elapsed = now - lastAward;
        if (elapsed < DAY_IN_MS) {
          cooldownMs = DAY_IN_MS - elapsed;
        }
      }
      if (!allHigh) {
        return { awarded: false, allHigh: false, streak: state.infinite.streak, cooldownMs };
      }
      if (cooldownMs > 0) {
        return { awarded: false, allHigh: true, streak: state.infinite.streak, cooldownMs };
      }
      state.infinite.streak = Math.max(0, Number(state.infinite.streak) || 0) + 1;
      state.infinite.lastCheckInDay = toDayKey(now);
      state.infinite.lastCheckInAt = now;
      updateInteractionTimestamp();
      scheduleSave(true);
      return { awarded: true, allHigh: true, streak: state.infinite.streak, cooldownMs: 0 };
    },
    getInfiniteOverview() {
      ensureReady();
      return clone({
        appearance: state.infinite.appearance,
        streak: state.infinite.streak,
        stats: getStatsSnapshot(),
        lastCheckInAt: state.infinite.lastCheckInAt,
        lastCheckInDay: state.infinite.lastCheckInDay,
        previousInteraction: state.infinite.previousInteraction,
        lastInteraction: state.infinite.lastInteraction
      });
    },
    clearInfiniteData() {
      ensureReady();
      // Reset infinite mode data to defaults
      state.infinite.appearance = null;
      state.infinite.streak = 0;
      state.infinite.lastCheckInAt = null;
      state.infinite.lastCheckInDay = null;
      state.infinite.lastInteraction = null;
      state.infinite.previousInteraction = null;
      state.infinite.stats.hunger = 50;
      state.infinite.stats.sleep = 50;
      state.infinite.stats.happiness = 50;
      scheduleSave(true);
    }
  };

  global.StateStore = api;
})(window);





