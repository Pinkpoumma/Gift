// js/config.js - Game configuration and constants
const GameConfig = {
  // Difficulty settings
  difficulties: {
    tutorial: {
      name: 'Tutorial',
      statDecayRate: 0, // No decay in tutorial
      minigameSpeed: 0.5,
      minigameDifficulty: 'easy',
      hints: true
    },
    pikmin: {
      name: 'Pikmin (Easy)',
      statDecayRate: 4,
      minigameSpeed: 1.0,
      minigameDifficulty: 'normal',
      hints: false
    },
    kuchi: {
      name: 'Kuchi (EXTREME)',
      statDecayRate: 15,
      minigameSpeed: 2.0,
      minigameDifficulty: 'extreme',
      hints: false,
      specialChallenges: true
    },
    infinite: {
      name: 'Infinite',
      statDecayRate: 1,
      minigameSpeed: 1.0,
      minigameDifficulty: 'normal',
      hints: false
    }
  },
  
  // Minigame settings
  minigames: {
    feed: {
      rounds: {
        tutorial: 3,
        pikmin: 5,
        kuchi: 7,
        infinite: 5
      },
      winBonus: {
        tutorial: 20,
        pikmin: 15,
        kuchi: 10,
        infinite: 15
      },
      losePenalty: {
        tutorial: 0,
        pikmin: -10,
        kuchi: -20,
        infinite: -5
      }
    },
    sleep: {
      rounds: 5,
      sheepSpeed: {
        tutorial: 2000, // ms per sheep
        pikmin: 1500,
        kuchi: 267,
        infinite: 1500
      }
    },
    play: {
      ballSpeed: {
        tutorial: 1,
        pikmin: 1.5,
        kuchi: 2,
        infinite: 1.5
      },
      hitWindow: {
        tutorial: 200, // ms
        pikmin: 150,
        kuchi: 75,
        infinite: 150
      }
    }
  },
  
  // Pet stats
  stats: {
    maxValue: 100,
    startingValue: 50,
    criticalThreshold: 20,
    happyThreshold: 80
  },
  
  // Animation speeds
  animations: {
    fadeTime: 250,
    popupTime: 1500,
    petIdleSpeed: 3000
  }
};