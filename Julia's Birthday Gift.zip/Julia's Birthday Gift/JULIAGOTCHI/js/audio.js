// js/audio.js - Audio management system
const AudioManager = {
  audioElements: {},
  musicVolume: 1.0,
  sfxVolume: 1.0,

  init() {
    // Store references to all audio elements
    this.audioElements = {
      intro: document.getElementById('introMusic'),
      transition: document.getElementById('transitionMusic'),
      button: document.getElementById('btnSound'),
      select: document.getElementById('selectSound')
    };

    // Set initial volumes
    if (this.audioElements.intro) {
      this.audioElements.intro.volume = this.musicVolume;
    }
    if (this.audioElements.transition) {
      this.audioElements.transition.volume = this.musicVolume;
    }
    const lobbyMusic = document.getElementById('lobbyMusic');
    if (lobbyMusic) {
      lobbyMusic.volume = this.musicVolume;
    }
  },

  setMusicVolume(value) {
    this.musicVolume = value / 100;

    if (this.audioElements.intro) {
      this.audioElements.intro.volume = this.musicVolume;
    }
    if (this.audioElements.transition) {
      this.audioElements.transition.volume = this.musicVolume;
    }
    const lobbyMusic = document.getElementById('lobbyMusic');
    if (lobbyMusic) {
      lobbyMusic.volume = this.musicVolume;
    }

    const musicValue = document.getElementById('musicValue');
    if (musicValue) {
      musicValue.textContent = `${value}%`;
    }
    const menuMusicValue = document.getElementById('menuMusicValue');
    if (menuMusicValue) {
      menuMusicValue.textContent = `${value}%`;
    }
  },

  setSfxVolume(value) {
    this.sfxVolume = value / 100;

    const sfxValue = document.getElementById('sfxValue');
    if (sfxValue) {
      sfxValue.textContent = `${value}%`;
    }
    const menuSfxValue = document.getElementById('menuSfxValue');
    if (menuSfxValue) {
      menuSfxValue.textContent = `${value}%`;
    }
  },

  playIntroMusic() {
    const intro = this.audioElements.intro;
    if (!intro) return;

    intro.play().catch(() => {
      console.log('Autoplay prevented - music will start on first user interaction');
      const startMusicOnInteraction = () => {
        intro.play().catch(e => console.log('Could not play intro music:', e));
        document.removeEventListener('click', startMusicOnInteraction);
      };
      document.addEventListener('click', startMusicOnInteraction);
    });
  },

  fadeOutIntroAndPlayTransition(callback) {
    const intro = this.audioElements.intro;
    const transition = this.audioElements.transition;

    if (!intro) {
      if (callback) callback();
      return;
    }

    if (transition) {
      transition.currentTime = 0;
      transition.volume = this.musicVolume;
      transition.play().catch(e => console.log('Could not play transition:', e));
    }

    const fadeInterval = 20;
    const fadeSteps = 400 / fadeInterval;
    const volumeStep = intro.volume / fadeSteps;
    let currentStep = 0;

    const fade = setInterval(() => {
      currentStep++;
      intro.volume = Math.max(0, intro.volume - volumeStep);

      if (currentStep >= fadeSteps || intro.volume <= 0) {
        clearInterval(fade);
        intro.pause();
        intro.currentTime = 0;
        intro.volume = this.musicVolume;

        if (callback) callback();
      }
    }, fadeInterval);
  },

  stopTransitionMusic() {
    const transition = this.audioElements.transition;
    if (transition) {
      transition.pause();
      transition.currentTime = 0;
    }
  },

  playSound(soundName) {
    const audio = this.audioElements[soundName];
    if (audio) {
      audio.currentTime = 0;
      audio.volume = this.sfxVolume;
      audio.play().catch(e => console.log(`Could not play ${soundName}:`, e));
    }
  },

  restartIntroMusic() {
    const intro = this.audioElements.intro;
    if (intro) {
      intro.currentTime = 0;
      intro.volume = this.musicVolume;
      intro.play().catch(e => console.log('Could not restart intro music:', e));
    }
  },

  stopAllMusic() {
    if (this.audioElements.intro) {
      this.audioElements.intro.pause();
      this.audioElements.intro.currentTime = 0;
    }
    if (this.audioElements.transition) {
      this.audioElements.transition.pause();
      this.audioElements.transition.currentTime = 0;
    }
    const lobbyMusic = document.getElementById('lobbyMusic');
    if (lobbyMusic) {
      lobbyMusic.pause();
      lobbyMusic.currentTime = 0;
    }
  }
};

