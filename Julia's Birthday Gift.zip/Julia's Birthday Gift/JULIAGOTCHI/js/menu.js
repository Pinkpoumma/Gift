// js/menu.js - Menu screen controller
const MenuController = {
  init() {
    const playBtn = document.getElementById('playBtn');
    
    if (playBtn) {
      playBtn.addEventListener('click', () => {
        AudioManager.playSound('button');
        App.transitionToScreen('menu', 'difficulty');
      });
    }

    // Add logo intro animation
    this.animateLogo();
  },
  
  animateLogo() {
    const logo = document.querySelector('.logo');
    if (logo) {
      logo.style.opacity = '0';
      logo.style.transform = 'scale(0.5) rotate(-10deg)';
      
      // Animate in at 1 second mark to match crescendo
      setTimeout(() => {
        logo.style.transition = 'all 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
        logo.style.opacity = '1';
        logo.style.transform = 'scale(1) rotate(0deg)';
      }, 200);
    }
  },
  
  toggleMenuAudio() {
    const panel = document.getElementById('menuAudioPanel');
    if (panel) {
      panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }
  }
};
