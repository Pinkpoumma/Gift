// js/background.js - Animated spiral background generator
const BackgroundGenerator = {
  init() {
    const spiralContainers = document.querySelectorAll('.spiral');
    spiralContainers.forEach(container => {
      this.generateSpiral(container);
    });
  },
  
  generateSpiral(spiralContainer) {
    if (!spiralContainer) return;
    
    let elements = '';
    
    // Big twinkling stars (distributed to edges with color intensity)
    for (let i = 0; i < 40; i++) {
      const x = (Math.random() - 0.5) * 4500;
      const y = (Math.random() - 0.5) * 4500;
      const size = Math.random() * 20 + 12;
      
      const distanceFromCenter = Math.sqrt(x*x + y*y);
      const maxDistance = Math.sqrt(2250*2250 + 2250*2250);
      const colorIntensity = Math.min(1, distanceFromCenter / maxDistance * 1.5);
      const opacity = Math.max(0.3, colorIntensity * 0.8 + 0.2);
      
      const animationDelay = Math.random() * 4;
      const duration = Math.random() * 2 + 1.5;
      
      if (distanceFromCenter < 300) continue;
      
      elements += `
        <g transform="translate(${x}, ${y})" opacity="${opacity}">
          <animateTransform attributeName="transform" type="scale" 
                           values="0.5;1.2;0.5" dur="${duration}s" repeatCount="indefinite" 
                           begin="${animationDelay}s"/>
          <path d="M 0 ${-size} L ${size*0.2} ${-size*0.2} L ${size} 0 L ${size*0.2} ${size*0.2} L 0 ${size} L ${-size*0.2} ${size*0.2} L ${-size} 0 L ${-size*0.2} ${-size*0.2} Z" 
                fill="hsl(${320 + colorIntensity * 40}, ${60 + colorIntensity * 30}%, ${60 + colorIntensity * 20}%)"/>
        </g>
      `;
    }
    
    // Small sparkles
    for (let i = 0; i < 80; i++) {
      const x = (Math.random() - 0.5) * 4800;
      const y = (Math.random() - 0.5) * 4800;
      const size = Math.random() * 8 + 4;
      
      const distanceFromCenter = Math.sqrt(x*x + y*y);
      const maxDistance = Math.sqrt(2400*2400 + 2400*2400);
      const colorIntensity = Math.min(1, distanceFromCenter / maxDistance * 1.3);
      const opacity = Math.max(0.2, colorIntensity * 0.7 + 0.3);
      
      const animationDelay = Math.random() * 3;
      
      if (distanceFromCenter < 250) continue;
      
      elements += `
        <circle cx="${x}" cy="${y}" r="${size}" opacity="${opacity}"
                fill="hsl(${310 + colorIntensity * 50}, ${50 + colorIntensity * 35}%, ${65 + colorIntensity * 25}%)">
          <animate attributeName="opacity" values="${opacity};0.2;${opacity}" 
                   dur="3s" repeatCount="indefinite" begin="${animationDelay}s"/>
        </circle>
      `;
    }
    
    // Floating diamonds
    for (let i = 0; i < 25; i++) {
      const x = (Math.random() - 0.5) * 4200;
      const y = (Math.random() - 0.5) * 4200;
      const size = Math.random() * 12 + 8;
      
      const distanceFromCenter = Math.sqrt(x*x + y*y);
      const maxDistance = Math.sqrt(2100*2100 + 2100*2100);
      const colorIntensity = Math.min(1, distanceFromCenter / maxDistance * 1.4);
      const opacity = Math.max(0.2, colorIntensity * 0.6 + 0.3);
      
      const animationDelay = Math.random() * 5;
      
      if (distanceFromCenter < 350) continue;
      
      elements += `
        <g transform="translate(${x}, ${y})" opacity="${opacity}">
          <animateTransform attributeName="transform" type="translate" 
                           values="${x},${y}; ${x},${y-50}; ${x},${y}" 
                           dur="4s" repeatCount="indefinite" begin="${animationDelay}s"/>
          <path d="M 0 ${-size} L ${size*0.7} 0 L 0 ${size} L ${-size*0.7} 0 Z" 
                fill="hsl(${315 + colorIntensity * 45}, ${55 + colorIntensity * 30}%, ${60 + colorIntensity * 25}%)"/>
        </g>
      `;
    }
    
    // Shooting stars
    for (let i = 0; i < 3; i++) {
      const startX = -2500;
      const startY = -2000 + Math.random() * 1500;
      const endX = 2500;
      const endY = startY + 1500 + Math.random() * 1000;
      const animationDelay = Math.random() * 15;
      const duration = 2.5 + Math.random() * 1;
      
      elements += `
        <g opacity="0">
          <animate attributeName="opacity" values="0;1;1;0" 
                   dur="${duration}s" repeatCount="indefinite" begin="${animationDelay}s"/>
          <animateTransform attributeName="transform" type="translate"
                           values="0,0; ${endX - startX},${endY - startY}"
                           dur="${duration}s" repeatCount="indefinite" begin="${animationDelay}s"/>
          <circle cx="${startX + 100}" cy="${startY + 20}" r="4" fill="#fff" opacity="1"/>
          <circle cx="${startX + 100}" cy="${startY + 20}" r="7" fill="#fff" opacity="0.5"/>
          <line x1="${startX}" y1="${startY}" x2="${startX + 100}" y2="${startY + 20}" 
                stroke="#fff" stroke-width="3" stroke-linecap="round"/>
          <line x1="${startX}" y1="${startY}" x2="${startX + 60}" y2="${startY + 12}" 
                stroke="#fff" stroke-width="2" opacity="0.7" stroke-linecap="round"/>
          <line x1="${startX}" y1="${startY}" x2="${startX + 30}" y2="${startY + 6}" 
                stroke="#fff" stroke-width="1" opacity="0.4" stroke-linecap="round"/>
        </g>
      `;
    }
    
    spiralContainer.innerHTML = `
      <svg viewBox="-2500 -2500 5000 5000" 
           xmlns="http://www.w3.org/2000/svg" 
           preserveAspectRatio="xMidYMid slice">
        <defs>
          <radialGradient id="bgGradient">
            <stop offset="0%" stop-color="#ffeef8" stop-opacity="0.1"/>
            <stop offset="70%" stop-color="#ffe4f2" stop-opacity="0.05"/>
            <stop offset="100%" stop-color="#ffd9ed" stop-opacity="0.02"/>
          </radialGradient>
        </defs>
        
        <rect x="-2500" y="-2500" width="5000" height="5000" 
              fill="url(#bgGradient)"/>
        
        ${elements}
      </svg>
    `;
  }
};