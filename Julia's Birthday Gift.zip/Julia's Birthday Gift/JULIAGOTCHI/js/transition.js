// js/transition.js - Screen transition effects
const ScreenTransition = (() => {
  let overlay = null;
  let cleanupTimeout = null;

  const ensureOverlay = () => {
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.className = 'screen-wipe';

      const layer = document.createElement('div');
      layer.className = 'screen-wipe__layer';
      overlay.appendChild(layer);

      document.body.appendChild(overlay);
    }
    return overlay;
  };

  const startAnimation = ({ direction, duration }) => {
    const element = ensureOverlay();

    element.classList.remove('reverse', 'animate', 'active');

    // Force reflow so animations restart cleanly
    void element.offsetWidth;

    if (direction === 'reverse') {
      element.classList.add('reverse');
    }

    element.classList.add('active');

    requestAnimationFrame(() => {
      element.classList.add('animate');
    });

    clearTimeout(cleanupTimeout);
    cleanupTimeout = setTimeout(() => {
      element.classList.remove('animate', 'active', 'reverse');
    }, duration);
  };

  const play = ({ direction = 'forward', delay = 0, duration = 1050 } = {}) => {
    const options = { direction, duration };
    if (delay > 0) {
      setTimeout(() => startAnimation(options), delay);
    } else {
      startAnimation(options);
    }
  };

  return { play };
})();
