﻿// js/minigames/sleep.js - Sheep counting sleep minigame
const SleepMinigame = {
  isPlaying: false,
  currentRound: 0,
  maxRounds: 5,
  sheepCount: 0,
  correctCount: 0,
  currentSheepInRound: 0,
  currentStatValue: 0,
  targetStatValue: 0,
  speedMultiplier: 1,
  rewardMultiplier: 1,
  speedModeActive: false,
  
  start() {
    if (this.isPlaying || GameController.currentMinigame) return;

    this.isPlaying = true;
    GameController.currentMinigame = 'sleep';
    GameController.pauseStatDecay();

    this.speedMultiplier = 1;
    this.rewardMultiplier = 1;
    this.speedModeActive = false;
    this.currentRound = 0;
    this.correctCount = 0;
    this.currentStatValue = GameController.pet.sleep;
    this.targetStatValue = GameController.pet.sleep;
    this.render();
    this.showCountdown(() => this.nextRound());
  },

  showCountdown(callback) {
    const overlay = document.createElement('div');
    overlay.className = 'countdown-overlay';
    overlay.innerHTML = '<div class="countdown-number">3</div>';
    document.body.appendChild(overlay);

    // Play countdown sound once at the start
    try {
      const countdownSound = new Audio('assets/audio/countdown.mp3');
      if (typeof AudioManager !== 'undefined') {
        countdownSound.volume = AudioManager.sfxVolume * 0.7;
      }
      countdownSound.play().catch(e => console.log('Could not play countdown sound'));
    } catch (e) {
      console.log('Could not load countdown sound');
    }

    const countdownSteps = [
      { text: '3', color: '#ff4444', delay: 0 },
      { text: '2', color: '#ff8800', delay: 1000 },
      { text: '1', color: '#ffcc00', delay: 2000 },
      { text: 'GO!', color: '#44ff44', delay: 3000 }
    ];

    let currentStep = 0;
    const numberEl = overlay.querySelector('.countdown-number');

    const showStep = () => {
      if (currentStep < countdownSteps.length) {
        const step = countdownSteps[currentStep];
        numberEl.textContent = step.text;
        numberEl.style.color = step.color;
        numberEl.style.animation = 'none';
        setTimeout(() => {
          numberEl.style.animation = 'countdownPop 0.8s ease-out';
        }, 10);

        currentStep++;

        if (currentStep < countdownSteps.length) {
          setTimeout(showStep, 1000);
        } else {
          setTimeout(() => {
            overlay.remove();
            if (callback) callback();
          }, 800);
        }
      }
    };

    showStep();
  },
  
  render() {
    const container = document.getElementById('minigameContainer');
    container.innerHTML = `
      <div class="minigame-overlay">
        <div class="minigame-wrapper">
          <div class="minigame-content sleep-game">
            <div class="minigame-header">
              <h2>😴 Counting Sheep 😴</h2>
            </div>
            
            <div class="minigame-body">
              <p class="minigame-instructions">
                Count ONLY the sheep to help your pet sleep! Ignore the hamsters!
                ${GameController.difficulty === 'tutorial' ? '<br><em>Hint: Only count the sheep, not the hamsters!</em>' : ''}
                ${GameController.difficulty === 'kuchi' ? '<br><em>⚠️ EXTREME: Dont Blink!</em>' : ''}
              </p>

              <div class="sleep-speed-toggle">
                <button id="sleepSpeedToggle" type="button">Speed x1</button>
                <span class="speed-note" id="sleepSpeedNote">Normal rewards</span>
                <span class="speed-hint">💡 Click to speed up!</span>
              </div>

              <div class="sheep-field" id="sheepField">
                <!-- Animals will appear here -->
              </div>
              
              <div class="minigame-status">
                Round: <span id="roundCount">1/${this.maxRounds}</span> | 
                Score: <span id="sleepScore">0</span>
              </div>
              
              <div class="sheep-counter">
                <label>How many sheep did you count?</label>
                <input type="number" id="sheepInput" min="0" max="99" value="0">
                <button onclick="SleepMinigame.submitCount()">Submit</button>
              </div>
              
              <div id="countResult" class="count-result"></div>
              
              <button class="quit-minigame" onclick="SleepMinigame.end()">
                Wake Up
              </button>
            </div>
          </div>
          
          <div class="minigame-side-stat${GameController.difficulty === 'kuchi' ? ' kuchi-mode' : ''}">
            <div class="stat-label">😴</div>
            <div class="stat-vertical-bar">
              <div class="stat-vertical-fill" id="minigameSleepBar" style="height: ${this.currentStatValue}%"></div>
            </div>
            <div class="stat-value" id="minigameSleepValue">${Math.round(this.currentStatValue)}</div>
          </div>
        </div>
      </div>
    `;
    
    this.bindSpeedToggle();
    this.animateStatBar();
  },
  
  bindSpeedToggle() {
    const toggle = document.getElementById('sleepSpeedToggle');
    const note = document.getElementById('sleepSpeedNote');
    if (!toggle) {
      return;
    }
    const applyState = () => {
      if (this.speedModeActive) {
        toggle.textContent = 'Speed x2';
        if (note) {
          note.textContent = 'Rewards x1.5';
        }
        toggle.classList.add('is-active');
      } else {
        toggle.textContent = 'Speed x1';
        if (note) {
          note.textContent = 'Normal rewards';
        }
        toggle.classList.remove('is-active');
      }
    };
    toggle.onclick = () => {
      this.speedModeActive = !this.speedModeActive;
      this.speedMultiplier = this.speedModeActive ? 2 : 1;
      this.rewardMultiplier = this.speedModeActive ? 1.5 : 1;
      applyState();
    };
    applyState();
  },
  animateStatBar() {
    if (!this.isPlaying) return;
    
    if (Math.abs(this.currentStatValue - this.targetStatValue) > 0.5) {
      const diff = this.targetStatValue - this.currentStatValue;
      this.currentStatValue += diff * 0.1;
      
      const bar = document.getElementById('minigameSleepBar');
      const value = document.getElementById('minigameSleepValue');
      if (bar && value) {
        bar.style.height = `${this.currentStatValue}%`;
        value.textContent = Math.round(this.currentStatValue);
      }
    }
    
    requestAnimationFrame(() => this.animateStatBar());
  },
  
  nextRound() {
    this.currentRound++;
    if (this.currentRound > this.maxRounds) {
      this.finish();
      return;
    }
    
    // Clear field and result
    document.getElementById('sheepField').innerHTML = '';
    document.getElementById('countResult').innerHTML = '';
    document.getElementById('sheepInput').value = 0;
    document.getElementById('roundCount').textContent = `${this.currentRound}/${this.maxRounds}`;
    
    // Calculate number of animals for this round with randomization
    const difficulty = GameController.activeMode === 'infinite' ? 'infinite' : GameController.difficulty;

    // Randomize sheep count based on difficulty with bell curve distribution
    let sheepCount;
    if (difficulty === 'tutorial') {
      sheepCount = 2 + Math.floor(Math.random() * 3) + Math.floor(Math.random() * 3); // 2-7 sheep (bell curve favors 4-5)
    } else if (difficulty === 'kuchi') {
      sheepCount = 5 + Math.floor(Math.random() * 5) + Math.floor(Math.random() * 5); // 5-14 sheep (bell curve favors 9-10)
    } else if (difficulty === 'infinite') {
      sheepCount = 3 + Math.floor(Math.random() * 4) + Math.floor(Math.random() * 3); // 3-9 sheep (same as pikmin)
    } else {
      sheepCount = 3 + Math.floor(Math.random() * 4) + Math.floor(Math.random() * 3); // 3-9 sheep (bell curve favors 5-6)
    }

    // Randomize hamster count based on difficulty with more variety
    let hamsterCount;
    if (difficulty === 'tutorial') {
      hamsterCount = Math.floor(Math.random() * 3); // 0-2 hamsters
    } else if (difficulty === 'kuchi') {
      hamsterCount = 3 + Math.floor(Math.random() * 6) + Math.floor(Math.random() * 4); // 3-12 hamsters (more variety)
    } else if (difficulty === 'infinite') {
      hamsterCount = 1 + Math.floor(Math.random() * 3) + Math.floor(Math.random() * 3); // 1-6 hamsters (same as pikmin)
    } else {
      hamsterCount = 1 + Math.floor(Math.random() * 3) + Math.floor(Math.random() * 3); // 1-6 hamsters (bell curve)
    }

    this.currentSheepInRound = sheepCount;
    
    // Get speed settings
    const baseSpeed = GameConfig.minigames.sleep.sheepSpeed[difficulty];
    const getSpeed = () => Math.max(120, baseSpeed / this.speedMultiplier);
    
    // Create array of animals
    const animals = [];
    for (let i = 0; i < sheepCount; i++) {
      animals.push('sheep');
    }
    for (let i = 0; i < hamsterCount; i++) {
      animals.push('hamster');
    }
    
    // Shuffle animals
    animals.sort(() => Math.random() - 0.5);
    
    // Display animals one by one
    let index = 0;
    const displayAnimal = () => {
      if (index < animals.length) {
        this.showAnimal(animals[index]);
        index++;
        setTimeout(displayAnimal, getSpeed());
      } else {
        // Enable input after all animals shown
        document.getElementById('sheepInput').disabled = false;
        document.querySelector('.sheep-counter button').disabled = false;
      }
    };
    
    // Disable input during animation
    document.getElementById('sheepInput').disabled = true;
    document.querySelector('.sheep-counter button').disabled = true;
    
    // Start showing animals
    setTimeout(displayAnimal, 500);
  },
  
  showAnimal(animalType) {
    const field = document.getElementById('sheepField');
    const animalDiv = document.createElement('div');
    animalDiv.className = 'jumping-animal';

    // Create image element
    const img = document.createElement('img');
    img.src = `assets/images/${animalType}.png`;
    img.style.width = '135px'; // 50% wider again
    img.style.height = '90px';
    img.style.imageRendering = 'pixelated';
    animalDiv.appendChild(img);
    
    // Play sheep sound
    if (animalType === 'sheep') {
      const sheepSound = new Audio('assets/audio/sheep_bah.mp3');
      sheepSound.volume = 0.3;
      sheepSound.play().catch(e => console.log('Could not play sheep sound'));
    }
    
    // Random position
    const x = Math.random() * (field.clientWidth - 80);
    const y = Math.random() * (field.clientHeight - 80);
    animalDiv.style.left = `${x}px`;
    animalDiv.style.top = `${y}px`;
    
    // Add extra effects for Kuchi mode
    if (GameController.difficulty === 'kuchi') {
      animalDiv.classList.add('extreme-speed');
    }
    
    field.appendChild(animalDiv);
    
    // Remove after animation
    const baseDuration = GameController.difficulty === 'kuchi' ? 500 : 1500;
    const duration = Math.max(250, baseDuration / this.speedMultiplier);
    setTimeout(() => {
      animalDiv.remove();
    }, duration);
  },
  
  submitCount() {

    const guess = parseInt(document.getElementById('sheepInput').value) || 0;

    const correct = this.currentSheepInRound;

    const resultDiv = document.getElementById('countResult');



    const applyReward = (base) => {

      const adjusted = Math.round(base * this.rewardMultiplier * 10) / 10;

      this.targetStatValue = Math.min(100, Math.max(0, this.targetStatValue + adjusted));

      GameController.updateStat('sleep', adjusted);

      return adjusted;

    };



    if (guess === correct) {

      this.correctCount++;

      resultDiv.innerHTML = `<span class="win">Great job! There were ${correct} sheep!</span>`;

      applyReward(15);

    } else {

      const diff = Math.abs(guess - correct);

      if (diff === 1) {

        resultDiv.innerHTML = `<span class="close">Almost! There were ${correct} sheep.</span>`;

        applyReward(8);

      } else {

        resultDiv.innerHTML = `<span class="lose">There were ${correct} sheep, not ${guess}.</span>`;

        if (GameController.difficulty === 'kuchi') {

          this.targetStatValue = Math.max(0, this.targetStatValue - 5);

          GameController.updateStat('sleep', -5);

        }

      }

    }



    document.getElementById('sleepScore').textContent = this.correctCount;



    setTimeout(() => {

      this.nextRound();

    }, 2000);

  },


  finish() {

    const score = this.correctCount;

    const percentage = (score / this.maxRounds) * 100;

    let bonus = 0;

    let message = '';



    if (percentage >= 80) {

      bonus = 25;

      message = 'Perfect! Your pet is sleeping soundly.';

    } else if (percentage >= 60) {

      bonus = 15;

      message = 'Good job! Your pet is getting sleepy.';

    } else if (percentage >= 40) {

      bonus = 10;

      message = 'Not bad! Your pet is relaxing.';

    } else {

      bonus = 5;

      message = 'Your pet is still restless...';

      if (GameController.difficulty === 'kuchi') {

        bonus = -10;

        message = 'Your pet is having nightmares!';

      }

    }



    let adjustedBonus = bonus;

    if (bonus > 0) {

      adjustedBonus = Math.round(bonus * this.rewardMultiplier);

    }



    this.targetStatValue = Math.min(100, Math.max(0, this.targetStatValue + adjustedBonus));

    GameController.updateStat('sleep', adjustedBonus);



    document.getElementById('countResult').innerHTML = `

      <div class="final-result">

        ${message}<br>

        You counted correctly ${this.correctCount}/${this.maxRounds} times!

        ${adjustedBonus > 0 ? `<br>+${adjustedBonus} sleep bonus!` : adjustedBonus < 0 ? `<br>${adjustedBonus} sleep penalty!` : ''}

      </div>

    `;



    setTimeout(() => this.end(), 3000);

  },

  
  end() {
    this.isPlaying = false;
    this.currentRound = 0;
    this.correctCount = 0;
    GameController.currentMinigame = null;
    GameController.resumeStatDecay();

    // Check for pending extreme unlock popup
    if (GameController.checkAndShowExtremeUnlock) {
      GameController.checkAndShowExtremeUnlock();
    }

    const container = document.getElementById('minigameContainer');
    if (container) {
      container.innerHTML = '';
    }
    if (typeof document !== 'undefined') {
      document.dispatchEvent(new CustomEvent('tutorial:minigameEnd', { detail: { minigame: 'sleep' } }));
    }
  }
};

// Add CSS for sheep minigame
const sleepStyles = document.createElement('style');
sleepStyles.textContent = `
  .sleep-game .sheep-field {
    width: 400px;
    height: 300px;
    background: linear-gradient(180deg, #001848 0%, #002d6e 100%);
    border: 3px solid #fff;
    border-radius: 15px;
    margin: 20px auto;
    position: relative;
    overflow: hidden;
  }
  
  .jumping-animal {
    position: absolute;
    animation: jumpAcross 1.5s ease-out;
  }
  
  .jumping-animal img {
    display: block;
    width: 60px;
    height: 60px;
    image-rendering: pixelated;
  }
  
  .jumping-animal.extreme-speed {
    animation: jumpAcrossExtreme 0.5s ease-out;
  }
  
  .sheep-counter {
    margin: 20px 0;
  }
  
  .sheep-counter label {
    display: block;
    margin-bottom: 10px;
    font-size: 1.1rem;
  }
  
  .sheep-counter input {
    width: 80px;
    padding: 10px;
    font-size: 1.5rem;
    text-align: center;
    margin: 0 10px;
    border: 2px solid #667eea;
    border-radius: 10px;
    font-family: 'PastelCrayon', sans-serif;
  }
  
  .sheep-counter button {
    padding: 10px 20px;
    font-size: 1.1rem;
  }
  
  .count-result {
    min-height: 30px;
    margin: 20px 0;
  }
  .sleep-speed-toggle {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 12px;
    margin: 12px 0 18px;
  }
  
  .sleep-speed-toggle button {
    padding: 8px 18px;
    font-size: 1rem;
  }
  
  .sleep-speed-toggle button.is-active {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: #fff;
  }
  
  .sleep-speed-toggle .speed-note {
    font-size: 0.95rem;
    color: #5a4a7a;
    font-weight: 600;
  }

  .sleep-speed-toggle .speed-hint {
    font-size: 0.85rem;
    color: #888;
    font-style: italic;
    margin-left: 8px;
  }


  .count-result .close {
    color: #ffa500;
    font-weight: bold;
  }
  
  @keyframes jumpAcross {
    0% {
      transform: translateY(0) scale(0);
      opacity: 0;
    }
    20% {
      transform: translateY(-30px) scale(1);
      opacity: 1;
    }
    50% {
      transform: translateY(-50px) scale(1.2);
    }
    80% {
      transform: translateY(-30px) scale(1);
      opacity: 1;
    }
    100% {
      transform: translateY(0) scale(0.8);
      opacity: 0;
    }
  }
  
  @keyframes jumpAcrossExtreme {
    0% {
      transform: translateY(0) scale(0);
      opacity: 0;
    }
    50% {
      transform: translateY(-50px) scale(1.5);
      opacity: 1;
    }
    100% {
      transform: translateY(0) scale(0);
      opacity: 0;
    }
  }
  
  @media (max-width: 768px) {
    .sleep-game .sheep-field {
      width: 300px;
      height: 250px;
    }
  }
`;
document.head.appendChild(sleepStyles);










