// js/minigames/play.js - Baseball timing minigame
const PlayMinigame = {
  isPlaying: false,
  ballsThrown: 0,
  maxBalls: 10,
  hits: 0,
  currentBall: null,
  ballPosition: 0,
  ballSpeed: 1,
  hitWindow: 150,
  animationFrame: null,
  statAnimationFrame: null,
  currentStatValue: 0,
  targetStatValue: 0,
  
  start() {
    if (this.isPlaying || GameController.currentMinigame) return;
    
    this.isPlaying = true;
    GameController.currentMinigame = 'play';
    GameController.pauseStatDecay();

    this.currentStatValue = GameController.pet ? GameController.pet.happiness : 0;
    this.targetStatValue = this.currentStatValue;

    // Get difficulty settings - use activeMode for infinite, otherwise difficulty
    const difficulty = GameController.activeMode === 'infinite' ? 'infinite' : GameController.difficulty;
    this.ballSpeed = GameConfig.minigames.play.ballSpeed[difficulty];
    this.hitWindow = GameConfig.minigames.play.hitWindow[difficulty];
    
    this.ballsThrown = 0;
    this.hits = 0;
    this.currentBall = null; // Reset current ball
    
    this.render();

    if (this.statAnimationFrame) {
      cancelAnimationFrame(this.statAnimationFrame);
      this.statAnimationFrame = null;
    }
    this.animateStatBar();

    this.setupControls();
    this.showCountdown(() => setTimeout(() => this.throwBall(), 1000));
  },

  showCountdown(callback) {
    const overlay = document.createElement('div');
    overlay.className = 'countdown-overlay';
    overlay.innerHTML = '<div class="countdown-number">3</div>';
    document.body.appendChild(overlay);

    // Play countdown sound once at the start
    try {
      const countdownSound = new Audio('assets/audio/countdown.mp3');
      if (typeof AudioManager !== 'undefined') {
        countdownSound.volume = AudioManager.sfxVolume * 0.7;
      }
      countdownSound.play().catch(e => console.log('Could not play countdown sound'));
    } catch (e) {
      console.log('Could not load countdown sound');
    }

    const countdownSteps = [
      { text: '3', color: '#ff4444', delay: 0 },
      { text: '2', color: '#ff8800', delay: 1000 },
      { text: '1', color: '#ffcc00', delay: 2000 },
      { text: 'GO!', color: '#44ff44', delay: 3000 }
    ];

    let currentStep = 0;
    const numberEl = overlay.querySelector('.countdown-number');

    const showStep = () => {
      if (currentStep < countdownSteps.length) {
        const step = countdownSteps[currentStep];
        numberEl.textContent = step.text;
        numberEl.style.color = step.color;
        numberEl.style.animation = 'none';
        setTimeout(() => {
          numberEl.style.animation = 'countdownPop 0.8s ease-out';
        }, 10);

        currentStep++;

        if (currentStep < countdownSteps.length) {
          setTimeout(showStep, 1000);
        } else {
          setTimeout(() => {
            overlay.remove();
            if (callback) callback();
          }, 800);
        }
      }
    };

    showStep();
  },

  getPetSprite() {
    if (!GameController.pet) {
      return '🥚';
    }

    const petType = GameController.pet.type || 'pikmin';
    let spriteUrl = '';

    switch(petType) {
      case 'chikawa':
        spriteUrl = 'assets/sprites/chikawa_idle.png';
        break;
      case 'kuchi':
        spriteUrl = 'assets/sprites/kuchi_idle.png';
        break;
      case 'pikmin':
      default:
        spriteUrl = 'assets/sprites/pikmin_idle.png';
        break;
    }

    return `<img src="${spriteUrl}" alt="${petType}" style="
      width: 64px;
      height: 64px;
      image-rendering: pixelated;
      image-rendering: -moz-crisp-edges;
      image-rendering: crisp-edges;
    ">`;
  },

  render() {
    const container = document.getElementById('minigameContainer');
    container.innerHTML = `
      <div class="minigame-overlay">
        <div class="minigame-wrapper">
          <div class="minigame-content play-game">
            <h2>⚾ Baseball Time! ⚾</h2>
            <p class="minigame-instructions">
              Hit SPACEBAR when the ball is in the strike zone!
              ${GameController.difficulty === 'tutorial' ? '<br><em>Hint: Watch for the green zone!</em>' : ''}
              ${GameController.difficulty === 'kuchi' ? '<br><em>⚠️ EXTREME: I call this one the "THATS NOT FAIR"!</em>' : ''}
            </p>
            
            <div class="baseball-field">
              <div class="pitch-line">
                <div class="ball" id="ball">
                  <img src="assets/images/baseball_play.png" alt="Baseball" style="
                    width: 30px;
                    height: 30px;
                    image-rendering: pixelated;
                    animation: ballRotate 0.5s linear infinite;
                  ">
                </div>
              </div>
              <div class="strike-zone" id="strikeZone">
                <div class="zone-label">HIT!</div>
              </div>
              <div class="batter" id="batter">
                <div class="bat" id="bat">🏏</div>
                <div class="pet-batter">
                  ${this.getPetSprite()}
                </div>
              </div>
            </div>
            
            <div class="minigame-status">
              Balls: <span id="ballCount">1/${this.maxBalls}</span> | 
              Hits: <span id="hitCount">0</span>
            </div>
            
            <div class="hit-indicator" id="hitIndicator"></div>
            
            <div class="controls-hint">
              Press <kbd>SPACEBAR</kbd> to swing!
            </div>
            
            <button class="quit-minigame" onclick="PlayMinigame.end()">
              Stop Playing
            </button>
          </div>

          <div class="minigame-side-stat${GameController.difficulty === 'kuchi' ? ' kuchi-mode' : ''}">
            <div class="stat-label">😊</div>
            <div class="stat-vertical-bar">
              <div class="stat-vertical-fill" id="minigameHappyBar" style="height: ${this.currentStatValue}%"></div>
            </div>
            <div class="stat-value" id="minigameHappyValue">${Math.round(this.currentStatValue)}</div>
          </div>
        </div>
      </div>
    `;
    
    // Add extra effects for Kuchi mode
    if (GameController.difficulty === 'kuchi') {
      document.querySelector('.baseball-field').classList.add('extreme-field');
    }
  },

  animateStatBar() {
    if (!this.isPlaying) {
      return;
    }

    const bar = document.getElementById('minigameHappyBar');
    const value = document.getElementById('minigameHappyValue');

    if (Math.abs(this.currentStatValue - this.targetStatValue) > 0.5) {
      const diff = this.targetStatValue - this.currentStatValue;
      this.currentStatValue += diff * 0.12;
    } else {
      this.currentStatValue = this.targetStatValue;
    }

    if (bar && value) {
      bar.style.height = `${this.currentStatValue}%`;
      value.textContent = Math.round(this.currentStatValue);
    }

    this.statAnimationFrame = requestAnimationFrame(() => this.animateStatBar());
  },

  setupControls() {
    this.keyHandler = (e) => {
      if (e.code === 'Space' || e.key === ' ') {
        e.preventDefault();
        this.swing();
      }
    };
    
    document.addEventListener('keydown', this.keyHandler);
  },
  
  throwBall() {
    if (this.ballsThrown >= this.maxBalls) {
      this.finish();
      return;
    }
    
    this.ballsThrown++;
    document.getElementById('ballCount').textContent = `${this.ballsThrown}/${this.maxBalls}`;
    
    const ball = document.getElementById('ball');
    const bat = document.getElementById('bat');
    
    // Reset positions
    this.ballPosition = 0;
    ball.style.left = '0%';
    ball.style.top = '50%';
    ball.style.opacity = '1';
    ball.style.transform = 'translateY(-50%)';
    ball.style.transition = 'none';
    ball.style.animation = 'none';
    ball.classList.remove('curve-ball', 'fast-ball');
    bat.classList.remove('swinging');
    
    // Clear any previous animation frame
    // Cancel any ongoing animation
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame);
      this.animationFrame = null;
    }
    
    // Determine pitch type for Kuchi mode
    let pitchType = 'normal';
    if (GameController.difficulty === 'kuchi') {
      const rand = Math.random();
      if (rand < 0.3) {
        pitchType = 'curve';
      } else if (rand < 0.5) {
        pitchType = 'fast';
      }
    }
    
    // Start ball animation after a brief delay
    setTimeout(() => {
      this.currentBall = {
        startTime: Date.now(),
        swung: false,
        hit: false,
        pitchType: pitchType
      };
      
      // Apply special pitch effects
      if (pitchType === 'curve') {
        ball.classList.add('curve-ball');
        // Use slower animation for curve ball
        ball.style.animation = 'curveBall 2s ease-in-out';
      } else if (pitchType === 'fast') {
        ball.classList.add('fast-ball');
        this.ballSpeed = GameConfig.minigames.play.ballSpeed[GameController.difficulty] * 3;
      }
      
      this.animateBall();
    }, 100);
  },
  
  animateBall() {
    if (!this.currentBall) return;
    
    const ball = document.getElementById('ball');
    const elapsed = Date.now() - this.currentBall.startTime;
    
    // Calculate position (0-100%)
    const speed = this.currentBall.pitchType === 'fast' 
      ? this.ballSpeed * 3  // Fast ball is 3x speed
      : this.ballSpeed;
    
    this.ballPosition = (elapsed / 1000) * speed * 100;
    
    if (this.ballPosition >= 100) {
      // Ball passed
      if (!this.currentBall.swung) {
        this.showResult('strike');
      }
      // Reset ball speed if it was modified
      if (this.currentBall.pitchType === 'fast') {
        this.ballSpeed = GameConfig.minigames.play.ballSpeed[GameController.difficulty];
      }
      setTimeout(() => this.throwBall(), 1500);
      return;
    }
    
    // Update ball position (unless it's a curve ball which uses CSS animation)
    if (this.currentBall.pitchType !== 'curve') {
      ball.style.left = `${this.ballPosition}%`;
    }
    
    // Add speed trails for Kuchi mode
    if (GameController.difficulty === 'kuchi' && this.ballPosition > 10) {
      if (this.currentBall.pitchType === 'fast') {
        ball.style.boxShadow = '-30px 0 30px rgba(255, 0, 0, 0.9)';
      } else {
        ball.style.boxShadow = '-20px 0 20px rgba(255, 100, 0, 0.8)';
      }
    }
    
    // Continue animation
    this.animationFrame = requestAnimationFrame(() => this.animateBall());
  },
  
  swing() {
    if (!this.currentBall || this.currentBall.swung) return;
    
    this.currentBall.swung = true;
    const bat = document.getElementById('bat');
    bat.classList.add('swinging');
    
    // Check if hit (strike zone is around 70-85% of the pitch line)
    const hitZoneStart = 70;
    const hitZoneEnd = 85;
    
    // For curve ball, we need to calculate where it would be on the timeline
    let currentPos = this.ballPosition;
    if (this.currentBall.pitchType === 'curve') {
      // Estimate position based on time elapsed for curve ball
      const elapsed = (Date.now() - this.currentBall.startTime) / 1500; // 1.5s total duration
      currentPos = elapsed * 100;
    }
    
    // Calculate hit window based on difficulty
    const window = this.hitWindow / 1000 * this.ballSpeed * 100;
    const inZone = currentPos >= (hitZoneStart - window/2) && 
                   currentPos <= (hitZoneEnd + window/2);
    
    if (inZone) {
      // Hit!
      this.hits++;
      this.currentBall.hit = true;
      document.getElementById('hitCount').textContent = this.hits;
      this.showResult('hit');
      
      // Make ball fly away
      const ball = document.getElementById('ball');
      ball.style.animation = 'none';
      ball.style.transition = 'all 0.5s ease-out';
      ball.style.transform = 'translateY(-200px) translateX(200px) rotate(720deg)';
      ball.style.opacity = '0';
      
      // Update happiness
      this.targetStatValue = Math.min(100, Math.max(0, this.targetStatValue + 10));
      GameController.updateStat('happiness', 10);
      
      // Cancel animation
      cancelAnimationFrame(this.animationFrame);
      this.animationFrame = null;
      this.currentBall = null;
    } else {
      // Miss!
      this.showResult('miss');
      
      if (GameController.difficulty === 'kuchi') {
        this.targetStatValue = Math.min(100, Math.max(0, this.targetStatValue - 5));
        GameController.updateStat('happiness', -5);
      }
      
      // Cancel animation
      cancelAnimationFrame(this.animationFrame);
      this.animationFrame = null;
      this.currentBall = null;
    }
    
    // Reset speed if it was fast ball
    if (this.currentBall && this.currentBall.pitchType === 'fast') {
      this.ballSpeed = GameConfig.minigames.play.ballSpeed[GameController.difficulty];
    }
    
    // Prepare next ball
    setTimeout(() => this.throwBall(), 1500);
  },
  
  showResult(type) {
    const indicator = document.getElementById('hitIndicator');
    
    switch(type) {
      case 'hit':
        indicator.innerHTML = '<span class="hit-text">💥 HOME RUN! 💥</span>';
        indicator.className = 'hit-indicator show hit';
        break;
      case 'miss':
        indicator.innerHTML = '<span class="miss-text">❌ MISS! ❌</span>';
        indicator.className = 'hit-indicator show miss';
        break;
      case 'strike':
        indicator.innerHTML = '<span class="strike-text">⚠️ STRIKE! ⚠️</span>';
        indicator.className = 'hit-indicator show strike';
        break;
    }
    
    setTimeout(() => {
      indicator.className = 'hit-indicator';
    }, 1000);
  },
  
  finish() {
    const hitRate = this.hits / this.maxBalls;
    let bonus = 0;
    let message = '';
    
    if (hitRate >= 0.8) {
      bonus = 30;
      message = '🏆 CHAMPION! Your pet is ecstatic!';
    } else if (hitRate >= 0.6) {
      bonus = 20;
      message = '🎉 Great job! Your pet had lots of fun!';
    } else if (hitRate >= 0.4) {
      bonus = 10;
      message = '👍 Nice try! Your pet enjoyed playing!';
    } else if (hitRate >= 0.2) {
      bonus = 5;
      message = '😊 Your pet had some fun!';
    } else {
      bonus = 0;
      message = '😔 Better luck next time...';
      if (GameController.difficulty === 'kuchi') {
        bonus = -15;
        message = '💀 Your pet is devastated!';
      }
    }
    
    this.targetStatValue = Math.min(100, Math.max(0, this.targetStatValue + bonus));
    GameController.updateStat('happiness', bonus);
    
    document.getElementById('hitIndicator').innerHTML = `
      <div class="final-result">
        ${message}<br>
        You hit ${this.hits}/${this.maxBalls} balls!
        ${bonus > 0 ? `<br>+${bonus} happiness bonus!` : bonus < 0 ? `<br>${bonus} happiness penalty!` : ''}
      </div>
    `;
    document.getElementById('hitIndicator').className = 'hit-indicator show final';
    
    setTimeout(() => this.end(), 3000);
  },
  
  end() {
    // Clean up event listener
    if (this.keyHandler) {
      document.removeEventListener('keydown', this.keyHandler);
      this.keyHandler = null;
    }
    // Cancel any ongoing animation
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame);
      this.animationFrame = null;
    }

    if (this.statAnimationFrame) {
      cancelAnimationFrame(this.statAnimationFrame);
      this.statAnimationFrame = null;
    }

    // Reset game state
    this.isPlaying = false;
    this.ballsThrown = 0;
    this.hits = 0;
    this.currentBall = null;
    this.ballPosition = 0;

    this.currentStatValue = GameController.pet ? GameController.pet.happiness : 0;
    this.targetStatValue = this.currentStatValue;

    GameController.currentMinigame = null;
    GameController.resumeStatDecay();

    // Check for pending extreme unlock popup
    if (GameController.checkAndShowExtremeUnlock) {
      GameController.checkAndShowExtremeUnlock();
    }

    const container = document.getElementById('minigameContainer');
    if (container) {
      container.innerHTML = '';
    }
    if (typeof document !== 'undefined') {
      document.dispatchEvent(new CustomEvent('tutorial:minigameEnd', { detail: { minigame: 'play' } }));
    }
  }
};

// Add CSS for baseball minigame
const playStyles = document.createElement('style');
playStyles.textContent = `
  .play-game {
    max-width: 100%;
    overflow: hidden;
  }
  
  .play-game .baseball-field {
    width: 90%;
    max-width: 450px;
    height: 180px;
    background: linear-gradient(180deg, #87CEEB 0%, #98FB98 100%);
    border: 3px solid #8B4513;
    border-radius: 15px;
    margin: 20px auto;
    position: relative;
    overflow: hidden;
  }
  
  .baseball-field.extreme-field {
    background: linear-gradient(180deg, #ff6b6b 0%, #ffd93d 100%);
    animation: fieldShake 0.5s ease-in-out infinite;
  }
  
  .pitch-line {
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 2px;
    background: #8B4513;
    transform: translateY(-50%);
  }
  
  .ball {
    position: absolute;
    top: 50%;
    left: 0;
    transform: translateY(-50%);
    font-size: 30px;
    transition: none;
    z-index: 10;
  }
  
  .strike-zone {
    position: absolute;
    left: 70%;
    right: 15%;
    top: 30%;
    bottom: 30%;
    background: rgba(0, 255, 0, 0.2);
    border: 2px dashed #00ff00;
    border-radius: 10px;
  }
  
  .zone-label {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    font-size: 1rem;
    color: #00ff00;
    font-weight: bold;
    opacity: 0.5;
  }
  
  .batter {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    display: flex;
    align-items: center;
    gap: 5px;
  }
  
  .bat {
    font-size: 35px;
    transform-origin: bottom center;
    transition: transform 0.2s ease-out;
  }
  
  .bat.swinging {
    animation: batSwing 0.3s ease-out;
  }
  
  .pet-batter {
    font-size: 30px;
  }
  
  .hit-indicator {
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease;
  }
  
  .hit-indicator.show {
    opacity: 1;
  }
  
  .hit-indicator.hit .hit-text {
    color: #00c851;
    font-size: 1.3rem;
    font-weight: bold;
    animation: bounce 0.5s ease;
  }
  
  .hit-indicator.miss .miss-text {
    color: #ff4444;
    font-size: 1.2rem;
    font-weight: bold;
  }
  
  .hit-indicator.strike .strike-text {
    color: #ffbb33;
    font-size: 1.2rem;
    font-weight: bold;
  }
  
  .hit-indicator.final {
    height: auto;
  }
  
  .controls-hint {
    margin: 15px 0;
    font-size: 1rem;
    color: #666;
  }
  
  .controls-hint kbd {
    background: #f0f0f0;
    border: 1px solid #ccc;
    border-radius: 3px;
    padding: 3px 8px;
    font-family: monospace;
    font-size: 0.9rem;
  }
  
  @keyframes batSwing {
    0% {
      transform: rotate(0deg);
    }
    50% {
      transform: rotate(-90deg);
    }
    100% {
      transform: rotate(-45deg);
    }
  }
  
  @keyframes fieldShake {
    0%, 100% {
      transform: translateX(0);
    }
    25% {
      transform: translateX(-2px);
    }
    75% {
      transform: translateX(2px);
    }
  }
  
  @media (max-width: 768px) {
    .play-game .baseball-field {
      width: 100%;
      height: 150px;
      max-width: none;
    }
    
    .zone-label {
      font-size: 0.8rem;
    }
    
    .bat {
      font-size: 30px;
    }
    
    .pet-batter {
      font-size: 25px;
    }
  }
`;
document.head.appendChild(playStyles);

