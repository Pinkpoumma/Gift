// js/minigames/feed.js - Coin flip feeding minigame
const FeedMinigame = {
  isPlaying: false,
  currentRound: 0,
  maxRounds: 0,
  wins: 0,
  coinFlipping: false,
  statDisplay: null,
  currentStatValue: 0,
  targetStatValue: 0,
  
  start() {
    if (this.isPlaying || GameController.currentMinigame) return;

    this.isPlaying = true;
    GameController.currentMinigame = 'feed';
    GameController.pauseStatDecay();

    // Get difficulty settings
    const difficulty = GameController.difficulty;
    this.maxRounds = GameConfig.minigames.feed.rounds[difficulty];
    this.currentRound = 0;
    this.wins = 0;
    this.currentStatValue = GameController.pet.hunger;
    this.targetStatValue = GameController.pet.hunger;

    this.render();
    this.showCountdown(() => this.nextRound());
  },

  showCountdown(callback) {
    const overlay = document.createElement('div');
    overlay.className = 'countdown-overlay';
    overlay.innerHTML = '<div class="countdown-number">3</div>';
    document.body.appendChild(overlay);

    // Play countdown sound once at the start
    try {
      const countdownSound = new Audio('assets/audio/countdown.mp3');
      if (typeof AudioManager !== 'undefined') {
        countdownSound.volume = AudioManager.sfxVolume * 0.7;
      }
      countdownSound.play().catch(e => console.log('Could not play countdown sound'));
    } catch (e) {
      console.log('Could not load countdown sound');
    }

    const countdownSteps = [
      { text: '3', color: '#ff4444', delay: 0 },
      { text: '2', color: '#ff8800', delay: 1000 },
      { text: '1', color: '#ffcc00', delay: 2000 },
      { text: 'GO!', color: '#44ff44', delay: 3000 }
    ];

    let currentStep = 0;
    const numberEl = overlay.querySelector('.countdown-number');

    const showStep = () => {
      if (currentStep < countdownSteps.length) {
        const step = countdownSteps[currentStep];
        numberEl.textContent = step.text;
        numberEl.style.color = step.color;
        numberEl.style.animation = 'none';
        setTimeout(() => {
          numberEl.style.animation = 'countdownPop 0.8s ease-out';
        }, 10);

        currentStep++;

        if (currentStep < countdownSteps.length) {
          setTimeout(showStep, 1000);
        } else {
          setTimeout(() => {
            overlay.remove();
            if (callback) callback();
          }, 800);
        }
      }
    };

    showStep();
  },
  
  render() {
    const container = document.getElementById('minigameContainer');
    const numTrays = GameController.difficulty === 'kuchi' ? 20 : 2;

    container.innerHTML = `
      <div class="minigame-overlay">
        <div class="minigame-wrapper">
          <div class="minigame-content feed-game">
            <div class="minigame-header feed-header">
              <h2>🍔 Feeding Time! 🍔</h2>
            </div>

            <div class="minigame-body">
              <p class="minigame-instructions">
                Lift the right tray to find the broccoli and feed your pet!
                ${GameController.difficulty === 'tutorial' ? '<br><em>Hint: One tray has broccoli 🥦, the other has garbage ❌!</em>' : ''}
                ${GameController.difficulty === 'kuchi' ? '<br><em>⚠️ EXTREME: A few more wrong answers... </em>' : ''}
              </p>

              <div class="tray-container" id="trayContainer">
                <!-- Trays will be generated here -->
              </div>

              <div class="minigame-status">
                Round: <span id="roundCount">1/${this.maxRounds}</span> |
                Wins: <span id="winCount">0</span>
              </div>

              <div id="flipResult" class="flip-result"></div>

              <button class="quit-minigame" onclick="FeedMinigame.end()">
                Done Feeding
              </button>
            </div>
          </div>

          <div class="minigame-side-stat${GameController.difficulty === 'kuchi' ? ' kuchi-mode' : ''}">
            <div class="stat-label">😋</div>
            <div class="stat-vertical-bar">
              <div class="stat-vertical-fill" id="minigameHungerBar" style="height: ${this.currentStatValue}%"></div>
            </div>
            <div class="stat-value" id="minigameHungerValue">${Math.round(this.currentStatValue)}</div>
          </div>
        </div>
      </div>
    `;

    this.setupTrays();
    this.animateStatBar();
  },

  setupTrays() {
    const numTrays = GameController.difficulty === 'kuchi' ? 20 : 2;
    const correctTray = Math.floor(Math.random() * numTrays);
    const container = document.getElementById('trayContainer');

    container.innerHTML = '';
    for (let i = 0; i < numTrays; i++) {
      const tray = document.createElement('div');
      tray.className = 'tray';
      tray.innerHTML = `
        <div class="tray-top">🍽️</div>
        <div class="tray-content">${i === correctTray ? '🥦' : '❌'}</div>
      `;
      tray.onclick = () => this.liftTray(i, correctTray);
      container.appendChild(tray);
    }
  },
  
  animateStatBar() {
    if (!this.isPlaying) return;
    
    // Smoothly animate stat bar
    if (Math.abs(this.currentStatValue - this.targetStatValue) > 0.5) {
      const diff = this.targetStatValue - this.currentStatValue;
      this.currentStatValue += diff * 0.1; // Smooth animation
      
      const bar = document.getElementById('minigameHungerBar');
      const value = document.getElementById('minigameHungerValue');
      if (bar && value) {
        bar.style.height = `${this.currentStatValue}%`;
        value.textContent = Math.round(this.currentStatValue);
      }
    }
    
    requestAnimationFrame(() => this.animateStatBar());
  },
  
  nextRound() {
    this.currentRound++;
    if (this.currentRound > this.maxRounds) {
      this.finish();
      return;
    }

    document.getElementById('roundCount').textContent = `${this.currentRound}/${this.maxRounds}`;
    document.getElementById('flipResult').textContent = '';
    this.coinFlipping = false;
    this.setupTrays();
  },

  liftTray(chosenIndex, correctIndex) {
    if (this.coinFlipping) return;
    this.coinFlipping = true;

    const trays = document.querySelectorAll('.tray');
    const resultDiv = document.getElementById('flipResult');
    const chosenTray = trays[chosenIndex];

    // Disable all trays
    trays.forEach(tray => tray.style.pointerEvents = 'none');

    // Lift the chosen tray
    chosenTray.classList.add('lifted');

    setTimeout(() => {
      const won = chosenIndex === correctIndex;

      if (won) {
        this.wins++;
        resultDiv.innerHTML = `<span class="win">✅ You found the broccoli! +${GameConfig.minigames.feed.winBonus[GameController.difficulty]} hunger!</span>`;
        this.targetStatValue = Math.min(100, this.targetStatValue + GameConfig.minigames.feed.winBonus[GameController.difficulty]);
        GameController.updateStat('hunger', GameConfig.minigames.feed.winBonus[GameController.difficulty]);
      } else {
        resultDiv.innerHTML = `<span class="lose">❌ Wrong tray! That's garbage!</span>`;

        // Reveal the correct tray
        setTimeout(() => {
          trays[correctIndex].classList.add('lifted');
        }, 500);
      }

      document.getElementById('winCount').textContent = this.wins;

      setTimeout(() => {
        this.nextRound();
      }, 2000);
    }, 600);
  },
  
  finish() {
    const winRate = this.wins / this.maxRounds;
    let bonus = 0;
    let message = '';
    
    if (winRate >= 0.8) {
      bonus = 20;
      message = '🎉 Amazing! Your pet is well fed!';
    } else if (winRate >= 0.5) {
      bonus = 10;
      message = '👍 Good job! Your pet is satisfied!';
    } else if (winRate >= 0.25) {
      bonus = 0;
      message = '😐 Your pet is still a bit hungry...';
    } else {
      bonus = GameConfig.minigames.feed.losePenalty[GameController.difficulty];
      message = '😢 Your pet is still very hungry!';
    }
    
    if (bonus !== 0) {
      this.targetStatValue = Math.min(100, Math.max(0, this.targetStatValue + bonus));
      GameController.updateStat('hunger', bonus);
    }
    
    document.getElementById('flipResult').innerHTML = `
      <div class="final-result">
        ${message}<br>
        You won ${this.wins}/${this.maxRounds} rounds!
        ${bonus > 0 ? `<br>+${bonus} hunger bonus!` : bonus < 0 ? `<br>${bonus} hunger penalty!` : ''}
      </div>
    `;
    
    setTimeout(() => this.end(), 3000);
  },
  
  end() {
    this.isPlaying = false;
    this.currentRound = 0;
    this.wins = 0;
    GameController.currentMinigame = null;
    GameController.resumeStatDecay();

    // Check for pending extreme unlock popup
    if (GameController.checkAndShowExtremeUnlock) {
      GameController.checkAndShowExtremeUnlock();
    }

    const container = document.getElementById('minigameContainer');
    if (container) {
      container.innerHTML = '';
    }
    if (typeof document !== 'undefined') {
      document.dispatchEvent(new CustomEvent('tutorial:minigameEnd', { detail: { minigame: 'feed' } }));
    }
  }
};


