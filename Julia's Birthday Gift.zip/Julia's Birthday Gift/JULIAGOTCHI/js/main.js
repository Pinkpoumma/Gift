// js/main.js - Main application entry point
const UIScaler = {
  maxScale: 1.25,
  minScale: 1,
  element: null,
  resizeObserver: null,
  currentScale: null,

  init() {
    this.element = document.querySelector('.app-scale');
    if (!this.element) {
      return;
    }

    this.updateScale = this.updateScale.bind(this);

    const resizeHandler = this.debounce(() => this.updateScale(), 80);
    this.boundResize = resizeHandler;
    window.addEventListener('resize', resizeHandler);
    window.addEventListener('orientationchange', resizeHandler);

    if (window.ResizeObserver) {
      this.resizeObserver = new ResizeObserver(() => this.updateScale());
      this.resizeObserver.observe(this.element);
    }

    requestAnimationFrame(() => this.updateScale());
  },

  getCurrentScale() {
    if (typeof this.currentScale === 'number') {
      return this.currentScale;
    }

    const raw = getComputedStyle(document.documentElement).getPropertyValue('--ui-scale');
    const parsed = parseFloat(raw);
    this.currentScale = Number.isFinite(parsed) ? parsed : 1;
    return this.currentScale;
  },

  updateScale() {
    if (!this.element) {
      return;
    }

    const currentScale = this.getCurrentScale();
    const rect = this.element.getBoundingClientRect();
    if (!rect.width || !rect.height) {
      return;
    }

    const naturalWidth = rect.width / currentScale;
    const naturalHeight = rect.height / currentScale;
    const availableWidth = window.innerWidth;
    const availableHeight = window.innerHeight;

    if (!availableWidth || !availableHeight) {
      return;
    }

    let targetScale = Math.min(this.maxScale, availableWidth / naturalWidth, availableHeight / naturalHeight);
    targetScale = Math.max(this.minScale, targetScale);

    if (typeof this.currentScale === 'number' && Math.abs(targetScale - this.currentScale) < 0.01) {
      return;
    }

    this.applyScale(targetScale);
  },

  applyScale(value) {
    if (!Number.isFinite(value)) {
      return;
    }

    this.currentScale = value;
    const root = document.documentElement;
    root.style.setProperty('--ui-scale', value.toFixed(3));
    root.style.setProperty('--ui-scale-inverse', (1 / value).toFixed(5));
  },

  debounce(fn, delay) {
    let timer = null;
    return () => {
      if (timer) {
        clearTimeout(timer);
      }
      timer = setTimeout(fn, delay);
    };
  }
};
document.addEventListener("DOMContentLoaded", () => {
  const boot = () => {
    UIScaler.init();

    // Initialize all modules
    AudioManager.init();
    BackgroundGenerator.init();
    MenuController.init();
    DifficultyController.init();

    // Start the application
    App.start();

    if (globalThis.StateStore && typeof globalThis.StateStore.recordInteraction === 'function') {
      try {
        globalThis.StateStore.recordInteraction();
      } catch (error) {
        console.warn('StateStore: initial interaction sync failed', error);
      }
      if (!globalThis.__tamogachiStateUnloadHooked) {
        globalThis.__tamogachiStateUnloadHooked = true;
        window.addEventListener('beforeunload', () => {
          try {
            if (globalThis.StateStore && typeof globalThis.StateStore.recordInteraction === 'function' && (!globalThis.StateStore.isReady || globalThis.StateStore.isReady())) {
              globalThis.StateStore.recordInteraction({ forceSave: true });
            }
          } catch (error) {
            console.warn('StateStore: failed to persist on unload', error);
          }
        });
      }
    }
  };

  const startSafely = () => {
    try {
      boot();
    } catch (error) {
      console.error('Failed to start application', error);
    }
  };

  startSafely();

  if (globalThis.StateStore && typeof globalThis.StateStore.init === 'function') {
    globalThis.StateStore.init().catch((error) => {
      console.warn('StateStore initialisation failed; continuing without persistence', error);
    });
  }
});

const App = {
  currentScreen: 'menu',
  selectedDifficulty: null,

  start() {
    console.log('JuliaGotchi starting...');

    // Set up click-to-start overlay
    const overlay = document.getElementById('clickToStartOverlay');
    const logo = document.querySelector('.logo');

    if (overlay && logo) {
      overlay.addEventListener('click', () => {
        // Hide text immediately
        const content = overlay.querySelector('.click-to-start-content');
        if (content) {
          content.style.display = 'none';
        }

        // Flash effect
        overlay.classList.add('flash');

        // Start audio
        AudioManager.playIntroMusic();

        setTimeout(() => {
          // Hide overlay
          overlay.classList.add('hidden');

          // Animate logo in
          logo.classList.add('animate-in');
        }, 250);
      });
    }
  },
  
  transitionToScreen(fromScreen, toScreen) {
    const from = document.querySelector(`.${fromScreen}-screen, .${fromScreen}`);
    const to = document.querySelector(`.${toScreen}-screen, .${toScreen}`);

    console.log('Transitioning from', fromScreen, 'to', toScreen);
    console.log('From element:', from);
    console.log('To element:', to);

    if (!from || !to) {
      console.error('Could not find screens!', { from, to });
      return;
    }

    // Add active class to new screen
    to.classList.add('active');
    console.log('Added active to:', to);

    // Remove active class from old screen after a tiny delay
    setTimeout(() => {
      from.classList.remove('active');
      console.log('Removed active from:', from);
    }, 10);

    this.currentScreen = toScreen;

    // Update extreme lock when returning to difficulty screen
    if (toScreen === 'difficulty' && typeof DifficultyController !== 'undefined' && DifficultyController.updateExtremeLock) {
      DifficultyController.updateExtremeLock();
    }

    if (UIScaler && typeof UIScaler.updateScale === 'function') {
      setTimeout(() => UIScaler.updateScale(), 120);
    }
  },
  
  startGame(difficulty, options = {}) {
    this.selectedDifficulty = difficulty;
    GameController.init(difficulty, options);
    this.transitionToScreen('difficulty', 'game');
  }
};
